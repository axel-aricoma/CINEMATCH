// 1. Guardamos el Token largo y la dirección base de la API
const API_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlZWMwZDI1NWNhMDk1ZDRiYzBhOGE1Yzc4MmQyNzMzMyIsIm5iZiI6MTc4NzMzMDA4Ny4xNzEsInN1YiI6IjZhODg3ZTI3YmM4ZWIxMzllZTE5YTY1MCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.e7ncUP3paeiwhsadCRd2baNQVdpISTI1V1C3xq69zzQ';
const API_URL = 'https://themoviedb.org';

// 2. Configuramos la petición incluyendo las credenciales de tu amigo
const opciones = {
  method: 'GET',
  headers: {
    accept: 'application/json',
    Authorization: `Bearer ${API_TOKEN}` // Aquí se inyecta el token
  }
};

// 3. Hacemos el llamado a la API para traer películas populares
fetch(API_URL, opciones)
  .then(respuesta => respuesta.json())
  .then(datos => {
    console.log('Películas recibidas:', datos.results);
    // Aquí puedes llamar a una función para mostrar las películas en tu HTML
    mostrarPeliculas(datos.results);
  })
  .catch(error => console.error('Error al conectar con TMDB:', error));

// 4. Función de ejemplo para pintar los datos en tu página
function mostrarPeliculas(peliculas) {
  // Asegúrate de tener un contenedor en tu HTML con id="lista-peliculas"
  const contenedor = document.getElementById('lista-peliculas'); 
  
  if(!contenedor) return;

  peliculas.forEach(pelicula => {
    const tarjeta = document.createElement('div');
    tarjeta.classList.add('tarjeta-pelicula');
    tarjeta.innerHTML = `
      <h3>${pelicula.title}</h3>
      <p>Estreno: ${pelicula.release_date}</p>
      <img src="https://tmdb.org{pelicula.poster_path}" alt="${pelicula.title}" style="width:100px;">
    `;
    contenedor.appendChild(tarjeta);
  });
}
