/* =====================================================
   PÁGINA DE DETALLE - CINEMATCH
   ===================================================== */


/* =====================================================
   OBTENER ID Y TIPO DESDE LA URL
   ===================================================== */

const parametros = new URLSearchParams(window.location.search);

const id = parametros.get("id");
const tipo = parametros.get("tipo") || "movie";


/* =====================================================
   ELEMENTOS HTML
   ===================================================== */

const loading = document.getElementById("loading");
const detalleContenido = document.getElementById("detalleContenido");

const poster = document.getElementById("poster");
const titulo = document.getElementById("titulo");
const rating = document.getElementById("rating");

const anio = document.getElementById("anio");
const duracion = document.getElementById("duracion");
const tipoContenido = document.getElementById("tipoContenido");

const generos = document.getElementById("generos");
const descripcion = document.getElementById("descripcion");

const actores = document.getElementById("actores");

const similaresSection = document.getElementById("similaresSection");
const similares = document.getElementById("similares");

const btnFavorito = document.getElementById("btnFavorito");
const btnVer = document.getElementById("btnVer");


/* =====================================================
   VARIABLES
   ===================================================== */

let contenidoActual = null;


/* =====================================================
   CARGAR INFORMACIÓN
   ===================================================== */

async function cargarDetalle() {

    if (!id) {

        mostrarError("No se encontró el contenido.");

        return;
    }


    try {

        const endpoint = tipo === "tv"
            ? `${TMDB_BASE_URL}/tv/${id}?language=es-ES&append_to_response=credits,recommendations`
            : `${TMDB_BASE_URL}/movie/${id}?language=es-ES&append_to_response=credits,recommendations`;


        const respuesta = await fetch(endpoint, options);


        if (!respuesta.ok) {

            throw new Error("No se pudo obtener la información.");

        }


        const datos = await respuesta.json();


        contenidoActual = datos;


        mostrarInformacion(datos);

        mostrarActores(datos.credits);

        mostrarSimilares(datos.recommendations);


        comprobarFavorito();

        comprobarVisto();


        loading.classList.add("oculto");

        detalleContenido.classList.remove("oculto");

        similaresSection.classList.remove("oculto");


    } catch (error) {

        console.error("Error:", error);

        mostrarError(
            "No se pudo cargar la información. Intentá nuevamente."
        );

    }

}


/* =====================================================
   MOSTRAR INFORMACIÓN
   ===================================================== */

function mostrarInformacion(datos) {

    const nombre = datos.title || datos.name;

    titulo.textContent = nombre;


    /* Poster */

    if (datos.poster_path) {

        poster.src = `${TMDB_IMG_URL}${datos.poster_path}`;

    } else {

        poster.src = "https://via.placeholder.com/500x750?text=Sin+imagen";

    }


    poster.alt = nombre;


    /* Puntuación */

    const puntuacion = datos.vote_average
        ? datos.vote_average.toFixed(1)
        : "-";

    rating.textContent = `⭐ ${puntuacion}`;


    /* Año */

    const fecha = datos.release_date || datos.first_air_date;

    if (fecha) {

        anio.textContent = fecha.substring(0, 4);

    } else {

        anio.textContent = "Año desconocido";

    }


    /* Tipo */

    if (tipo === "tv") {

        tipoContenido.textContent = "Serie";

    } else {

        tipoContenido.textContent = "Película";

    }


    /* Duración */

    if (tipo === "movie") {

        if (datos.runtime) {

            duracion.textContent = `${datos.runtime} min`;

        } else {

            duracion.textContent = "Duración desconocida";

        }

    } else {

        if (datos.number_of_seasons) {

            duracion.textContent =
                `${datos.number_of_seasons} temporada(s)`;

        } else {

            duracion.textContent = "Serie";

        }

    }


    /* Descripción */

    if (datos.overview) {

        descripcion.textContent = datos.overview;

    } else {

        descripcion.textContent =
            "No hay una descripción disponible para este contenido.";

    }


    /* Géneros */

    generos.innerHTML = "";


    if (datos.genres && datos.genres.length > 0) {

        datos.genres.forEach(genero => {

            const elemento = document.createElement("span");

            elemento.classList.add("genero");

            elemento.textContent = genero.name;

            generos.appendChild(elemento);

        });

    } else {

        generos.innerHTML =
            "<span class='genero'>Sin género</span>";

    }

}


/* =====================================================
   MOSTRAR ACTORES
   ===================================================== */

function mostrarActores(creditos) {

    actores.innerHTML = "";


    if (!creditos || !creditos.cast) {

        actores.innerHTML =
            "<p>No hay información de actores.</p>";

        return;
    }


    const listaActores = creditos.cast.slice(0, 8);


    listaActores.forEach(actor => {

        const tarjeta = document.createElement("div");

        tarjeta.classList.add("actor");


        let imagen = "https://via.placeholder.com/100x145?text=Sin+foto";


        if (actor.profile_path) {

            imagen = `${TMDB_IMG_URL}${actor.profile_path}`;

        }


        tarjeta.innerHTML = `

            <img
                src="${imagen}"
                alt="${actor.name}"
            >

            <p>${actor.name}</p>

        `;


        actores.appendChild(tarjeta);

    });

}


/* =====================================================
   MOSTRAR RECOMENDACIONES SIMILARES
   ===================================================== */

function mostrarSimilares(recomendaciones) {

    similares.innerHTML = "";


    if (!recomendaciones ||
        !recomendaciones.results ||
        recomendaciones.results.length === 0) {

        similares.innerHTML =
            "<p>No hay recomendaciones disponibles.</p>";

        return;
    }


    const lista = recomendaciones.results.slice(0, 6);


    lista.forEach(item => {

        if (!item.poster_path) {

            return;
        }


        const tarjeta = document.createElement("div");

        tarjeta.classList.add("similar-card");


        const nombre = item.title || item.name;

        const fecha =
            item.release_date ||
            item.first_air_date ||
            "";


        tarjeta.innerHTML = `

            <img
                src="${TMDB_IMG_URL}${item.poster_path}"
                alt="${nombre}"
            >

            <div class="similar-info">

                <h3>${nombre}</h3>

                <p>
                    ${fecha ? fecha.substring(0, 4) : "Sin año"}
                </p>

            </div>

        `;


        tarjeta.addEventListener("click", function() {

            const nuevoTipo =
                item.media_type === "tv" ||
                tipo === "tv"
                    ? "tv"
                    : "movie";


            window.location.href =
                `pelicula.html?id=${item.id}&tipo=${nuevoTipo}`;

        });


        similares.appendChild(tarjeta);

    });

}


/* =====================================================
   FAVORITOS
   ===================================================== */

function alternarFavorito() {

    if (!contenidoActual) {
        return;
    }


    let favoritos =
        JSON.parse(localStorage.getItem("cineMatchFavoritos")) || [];


    const existe = favoritos.some(item =>
        item.id === contenidoActual.id &&
        item.tipo === tipo
    );


    if (existe) {

        favoritos = favoritos.filter(item =>
            !(item.id === contenidoActual.id &&
              item.tipo === tipo)
        );

    } else {

        favoritos.push({

            id: contenidoActual.id,

            tipo: tipo,

            titulo:
                contenidoActual.title ||
                contenidoActual.name,

            poster:
                contenidoActual.poster_path

        });

    }


    localStorage.setItem(
        "cineMatchFavoritos",
        JSON.stringify(favoritos)
    );


    comprobarFavorito();

}


/* =====================================================
   COMPROBAR FAVORITO
   ===================================================== */

function comprobarFavorito() {

    if (!contenidoActual) {
        return;
    }


    const favoritos =
        JSON.parse(localStorage.getItem("cineMatchFavoritos")) || [];


    const existe = favoritos.some(item =>
        item.id === contenidoActual.id &&
        item.tipo === tipo
    );


    if (existe) {

        btnFavorito.classList.add("activo");

        btnFavorito.innerHTML = `
            <i class="fa-solid fa-heart"></i>
            <span>En favoritos</span>
        `;

    } else {

        btnFavorito.classList.remove("activo");

        btnFavorito.innerHTML = `
            <i class="fa-regular fa-heart"></i>
            <span>Agregar a favoritos</span>
        `;

    }

}


/* =====================================================
   MARCAR COMO "QUIERO VER"
   ===================================================== */

function alternarVisto() {

    if (!contenidoActual) {
        return;
    }


    let lista =
        JSON.parse(localStorage.getItem("cineMatchQuieroVer")) || [];


    const existe = lista.some(item =>
        item.id === contenidoActual.id &&
        item.tipo === tipo
    );


    if (existe) {

        lista = lista.filter(item =>
            !(item.id === contenidoActual.id &&
              item.tipo === tipo)
        );

    } else {

        lista.push({

            id: contenidoActual.id,

            tipo: tipo,

            titulo:
                contenidoActual.title ||
                contenidoActual.name,

            poster:
                contenidoActual.poster_path

        });

    }


    localStorage.setItem(
        "cineMatchQuieroVer",
        JSON.stringify(lista)
    );


    comprobarVisto();

}


/* =====================================================
   COMPROBAR "QUIERO VER"
   ===================================================== */

function comprobarVisto() {

    if (!contenidoActual) {
        return;
    }


    const lista =
        JSON.parse(localStorage.getItem("cineMatchQuieroVer")) || [];


    const existe = lista.some(item =>
        item.id === contenidoActual.id &&
        item.tipo === tipo
    );


    if (existe) {

        btnVer.classList.add("activo");

        btnVer.innerHTML = `
            <i class="fa-solid fa-eye"></i>
            <span>En mi lista</span>
        `;

    } else {

        btnVer.classList.remove("activo");

        btnVer.innerHTML = `
            <i class="fa-regular fa-eye"></i>
            <span>Quiero ver</span>
        `;

    }

}


/* =====================================================
   RECOMENDAR
   ===================================================== */

function recomendar() {

    if (!contenidoActual) {
        return;
    }


    const nombre =
        contenidoActual.title ||
        contenidoActual.name;


    const texto =
        `Te recomiendo ver "${nombre}" en CineMatch.`;


    if (navigator.share) {

        navigator.share({

            title: "CineMatch",

            text: texto,

            url: window.location.href

        });

    } else {

        navigator.clipboard.writeText(
            window.location.href
        );


        alert(
            "¡Enlace copiado! Ya podés compartirlo."
        );

    }

}


/* =====================================================
   VOLVER AL CATÁLOGO
   ===================================================== */

function volverCatalogo() {

    window.location.href = "catalogo.html";

}


/* =====================================================
   ERROR
   ===================================================== */

function mostrarError(mensaje) {

    loading.innerHTML = `

        <i class="fa-solid fa-triangle-exclamation"></i>

        <p>${mensaje}</p>

        <button
            class="btn-accion"
            onclick="volverCatalogo()">

            Volver al catálogo

        </button>

    `;

}


/* =====================================================
   INICIAR
   ===================================================== */

cargarDetalle();