// =========================================
// ELEMENTOS DEL HTML
// =========================================

const moviesGrid = document.getElementById("moviesGrid");
const genreList = document.getElementById("genreList");

const typeButtons = document.querySelectorAll(".type-btn");
const platformButtons = document.querySelectorAll(".platform-btn");

const catalogTitle = document.getElementById("catalogTitle");
const catalogSubtitle = document.getElementById("catalogSubtitle");


// =========================================
// VARIABLES
// =========================================

let currentGenre = "all";
let currentType = "all";
let currentPlatform = null;


// =========================================
// MOSTRAR PELÍCULAS
// =========================================

function renderMovies(movies) {

    if (!movies || movies.length === 0) {

        moviesGrid.innerHTML = `
            <p class="no-results">
                No se encontraron películas o series.
            </p>
        `;

        return;
    }


    moviesGrid.innerHTML = movies.map(movie => {

        // TMDB utiliza "title" para películas
        // y "name" para series.

        const title = movie.title || movie.name || "Sin título";

        const date =
            movie.release_date ||
            movie.first_air_date ||
            "";

        const year =
            date ?
            date.split("-")[0] :
            "S/D";


        const type =
            movie.media_type === "tv" ||
            movie.name ?
            "Serie" :
            "Película";


        const poster = movie.poster_path
            ? TMDB_IMG_URL + movie.poster_path
            : "https://via.placeholder.com/500x750?text=No+Poster";


        const rating =
            movie.vote_average
                ? movie.vote_average.toFixed(1)
                : "N/A";


        return `

            <article
                class="movie-card"
                onclick="abrirPelicula(${movie.id}, '${type}')"
            >

                <div class="poster-container">

                    <img
                        src="${poster}"
                        alt="${title}"
                    >

                    <div class="rating-badge">

                        <i class="fa-solid fa-star"></i>

                        ${rating}

                    </div>

                </div>


                <div class="movie-info">

                    <h3 class="movie-title">
                        ${title}
                    </h3>


                    <span class="movie-meta">

                        ${year} • ${type}

                    </span>


                    <p class="movie-description">

                        ${
                            movie.overview ||
                            "Sin descripción disponible."
                        }

                    </p>

                </div>

            </article>

        `;

    }).join("");
}


// =========================================
// CARGAR PELÍCULAS POPULARES
// =========================================

async function cargarPopulares() {

    moviesGrid.innerHTML = `
        <p class="catalog-loading">
            Cargando catálogo...
        </p>
    `;

    const movies = await fetchPopularMovies();

    catalogTitle.textContent = "Películas populares";

    catalogSubtitle.textContent =
        "Descubrí las películas más populares.";

    renderMovies(movies);
}


// =========================================
// FILTRO POR GÉNERO
// =========================================

genreList.addEventListener("click", async (event) => {

    const li = event.target.closest("li");

    if (!li) return;


    // Quitar selección anterior

    document
        .querySelectorAll("#genreList li")
        .forEach(item => {

            item.classList.remove("active");

        });


    // Activar seleccionado

    li.classList.add("active");


    currentGenre = li.dataset.genre;


    // Si seleccionamos todos

    if (currentGenre === "all") {

        cargarPopulares();

        return;
    }


    const genreId = GENRES_MAP[currentGenre];


    if (!genreId) return;


    moviesGrid.innerHTML = `
        <p class="catalog-loading">
            Buscando películas de ${currentGenre}...
        </p>
    `;


    const movies =
        await fetchMoviesByGenre(genreId);


    catalogTitle.textContent =
        currentGenre;


    catalogSubtitle.textContent =
        `Películas del género ${currentGenre}.`;


    renderMovies(movies);

});


// =========================================
// FILTRO PELÍCULAS / SERIES
// =========================================

typeButtons.forEach(button => {

    button.addEventListener("click", async () => {


        typeButtons.forEach(btn => {

            btn.classList.remove("active");

        });


        button.classList.add("active");


        currentType = button.dataset.type;


        moviesGrid.innerHTML = `
            <p class="catalog-loading">
                Cargando...
            </p>
        `;


        let movies = [];


        // Películas

        if (currentType === "movie") {

            movies = await fetchPopularMovies();


            movies = movies.map(movie => {

                movie.media_type = "movie";

                return movie;

            });

        }


        // Series

        else if (currentType === "tv") {

            movies =
                await obtenerSeriesPopulares();

        }


        // Todos

        else {

            movies =
                await fetchPopularMovies();

        }


        catalogTitle.textContent =
            currentType === "movie"
                ? "Películas"
                : currentType === "tv"
                    ? "Series"
                    : "Contenido popular";


        renderMovies(movies);

    });

});


// =========================================
// FILTRO DE PLATAFORMAS
// =========================================

// IMPORTANTE:
//
// Por ahora las plataformas solamente funcionan
// como selección visual.
//
// TODAVÍA NO consultamos watch/providers.
//
// Eso lo vamos a implementar más adelante.

platformButtons.forEach(button => {

    button.addEventListener("click", () => {

        platformButtons.forEach(btn => {

            btn.classList.remove("active");

        });


        button.classList.add("active");


        currentPlatform =
            button.dataset.platform;


        catalogSubtitle.textContent =
            `Plataforma seleccionada: ${currentPlatform}`;

    });

});


// =========================================
// ABRIR DETALLE
// =========================================

function abrirPelicula(id, type) {

    window.location.href =
        `pelicula.html?id=${id}&tipo=${type}`;

}


// =========================================
// CARGAR SERIES POPULARES
// =========================================

async function obtenerSeriesPopulares() {

    try {

        const response = await fetch(
            `${TMDB_BASE_URL}/tv/popular?language=es-ES&page=1`,
            options
        );


        const data =
            await response.json();


        return data.results || [];

    } catch (error) {

        console.error(
            "Error al obtener series:",
            error
        );

        return [];

    }

}


// =========================================
// INICIO DEL CATÁLOGO
// =========================================

cargarPopulares();