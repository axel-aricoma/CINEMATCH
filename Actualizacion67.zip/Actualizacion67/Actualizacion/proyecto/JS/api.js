
// ==============================
// CONFIGURACIÓN DE APIs
// ==============================
 //credenciales
const TMDB_API_KEY = 'eec0d255ca095d4bc0a8a5c782d27333';
const TMDB_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlZWMwZDI1NWNhMDk1ZDRiYzBhOGE1Yzc4MmQyNzMzMyIsIm5iZiI6MTc4NzMzMDA4Ny4xNzEsInN1YiI6IjZhODg3ZTI3YmM4ZWIxMzllZTE5YTY1MCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.e7ncUP3paeiwhsadCRd2baNQVdpISTI1V1C3xq69zzQ';
const OMDB_API_KEY = '7534ca63';

const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMG_URL = 'https://image.tmdb.org/t/p/w500';

// Configuración para las peticiones a TMDB
const options = {
    method: 'GET',
    headers: {
        accept: 'application/json',
        Authorization: `Bearer ${TMDB_TOKEN}`
    }
};


// ===============================
// GÉNEROS
// ===============================

const GENRES_MAP = {

    'Acción': 28,

    'Aventura': 12,

    'Animación': 16,

    'Comedia': 35,

    'Crimen': 80,

    'Documental': 99,

    'Drama': 18,

    'Familiar': 10751,

    'Fantasía': 14,

    'Misterio': 9648,

    'Romance': 10749,

    'Ciencia Ficción': 878,

    'Terror': 27,

    'Thriller': 53

};


// ===============================
// PELÍCULAS POPULARES
// ===============================

async function fetchPopularMovies(page = 1) {

    try {

        const res = await fetch(
            `${TMDB_BASE_URL}/movie/popular?language=es-ES&page=${page}`,
            options
        );

        const data = await res.json();

        return data.results || [];

    } catch (error) {

        console.error('Error al obtener películas populares:', error);

        return [];

    }

}


// ===============================
// BUSCAR PELÍCULAS POR GÉNERO
// ===============================

async function fetchMoviesByGenre(genreId) {

    try {

        const res = await fetch(
            `${TMDB_BASE_URL}/discover/movie?with_genres=${genreId}&language=es-ES&sort_by=popularity.desc`,
            options
        );

        const data = await res.json();

        return data.results || [];

    } catch (error) {

        console.error('Error al buscar películas por género:', error);

        return [];

    }

}


// ===============================
// RECOMENDACIONES DEL TEST
// ===============================

async function buscarRecomendaciones(preferencias) {

    try {

        /*
        ==========================================
        1. OBTENER GÉNEROS
        ==========================================
        */

        const generos = preferencias.generos || [];

        const genreIds = generos
            .map(genero => GENRES_MAP[genero])
            .filter(id => id);

        /*
        ==========================================
        2. DETERMINAR TIPO
        ==========================================
        */

        let tipo = preferencias.tipo || 'ambas';

        /*
        ==========================================
        3. URL DE TMDB
        ==========================================
        */

        let endpoint;

        if (tipo === 'serie') {

            endpoint = `${TMDB_BASE_URL}/discover/tv`;

        } else {

            // Para "película" y "ambas"
            endpoint = `${TMDB_BASE_URL}/discover/movie`;

        }

        /*
        ==========================================
        4. PARÁMETROS
        ==========================================
        */

        const params = new URLSearchParams();

        params.append('language', 'es-ES');

        params.append('sort_by', 'popularity.desc');

        params.append('page', '1');

        // Si hay géneros seleccionados
        if (genreIds.length > 0) {

            params.append(
                'with_genres',
                genreIds.join('|')
            );

        }

        // Solamente películas
        if (tipo === 'pelicula') {

            params.append(
                'vote_count.gte',
                '50'
            );

        }

        /*
        ==========================================
        5. REALIZAR CONSULTA
        ==========================================
        */

        const res = await fetch(
            `${endpoint}?${params.toString()}`,
            options
        );

        const data = await res.json();

        let resultados = data.results || [];


        /*
        ==========================================
        6. SI NO HAY RESULTADOS
        ==========================================
        */

        if (resultados.length === 0 && genreIds.length > 0) {

            console.log(
                'No hubo resultados con todos los géneros. Probando con el primer género.'
            );

            const fallback = await fetchMoviesByGenre(
                genreIds[0]
            );

            resultados = fallback;

        }


        /*
        ==========================================
        7. SI TODAVÍA NO HAY RESULTADOS
        ==========================================
        */

        if (resultados.length === 0) {

            console.log(
                'No hubo resultados específicos. Buscando populares.'
            );

            resultados = await fetchPopularMovies();

        }


        /*
        ==========================================
        8. FILTRAR SEGÚN EXPERIENCIA
        ==========================================
        */

        resultados = filtrarPorExperiencia(
            resultados,
            preferencias.ambiente
        );


        /*
        ==========================================
        9. FILTRAR SEGÚN DURACIÓN
        ==========================================
        */

        /*
        La duración de una película/serie no viene
        directamente en /discover.

        Por eso no eliminamos resultados acá.
        Más adelante podremos consultar los detalles
        de cada película.
        */


        /*
        ==========================================
        10. ORDENAR POR POPULARIDAD
        ==========================================
        */

        resultados.sort(
            (a, b) =>
                (b.popularity || 0) -
                (a.popularity || 0)
        );


        return resultados;

    } catch (error) {

        console.error(
            'Error al obtener recomendaciones:',
            error
        );

        return [];

    }

}


// ===============================
// FILTRO POR EXPERIENCIA
// ===============================

function filtrarPorExperiencia(
    resultados,
    ambiente
) {

    if (!ambiente) {

        return resultados;

    }


    /*
    ==========================================
    DIVERTIDO
    ==========================================
    */

    if (ambiente === 'divertido') {

        const resultadosFiltrados =
            resultados.filter(movie => {

                const generos =
                    movie.genre_ids || [];

                return (
                    generos.includes(35) ||
                    generos.includes(16) ||
                    generos.includes(10751)
                );

            });

        if (resultadosFiltrados.length > 0) {

            return resultadosFiltrados;

        }

    }


    /*
    ==========================================
    EMOCIÓN
    ==========================================
    */

    if (ambiente === 'emocion') {

        const resultadosFiltrados =
            resultados.filter(movie => {

                const generos =
                    movie.genre_ids || [];

                return (
                    generos.includes(28) ||
                    generos.includes(12) ||
                    generos.includes(53) ||
                    generos.includes(80)
                );

            });

        if (resultadosFiltrados.length > 0) {

            return resultadosFiltrados;

        }

    }


    /*
    ==========================================
    MIEDO
    ==========================================
    */

    if (ambiente === 'miedo') {

        const resultadosFiltrados =
            resultados.filter(movie => {

                const generos =
                    movie.genre_ids || [];

                return (
                    generos.includes(27) ||
                    generos.includes(53) ||
                    generos.includes(9648)
                );

            });

        if (resultadosFiltrados.length > 0) {

            return resultadosFiltrados;

        }

    }


    return resultados;

}