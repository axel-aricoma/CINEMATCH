// ==========================================
// CINECHALLENGE
// ==========================================


// Películas para el juego
const peliculasJuego = [

    {
        titulo: "Cadena perpetua",
        poster: "https://image.tmdb.org/t/p/w500/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg"
    },

    {
        titulo: "El padrino",
        poster: "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg"
    },

    {
        titulo: "El club de la pelea",
        poster: "https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg"
    },

    {
        titulo: "Matrix",
        poster: "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg"
    },

    {
        titulo: "Interestelar",
        poster: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg"
    },

    {
        titulo: "El señor de los anillos",
        poster: "https://image.tmdb.org/t/p/w500/lF2ic8LYuY7676viA0a2gimMYXc.jpg"
    }

];


// Variables
let preguntaActual = 0;

let puntaje = 0;

let racha = 0;

let tiempo = 10;

let intervalo;


// Elementos HTML
const posterJuego =
    document.getElementById("posterJuego");

const opciones =
    document.getElementById("opciones");

const puntajeElemento =
    document.getElementById("puntaje");

const rachaElemento =
    document.getElementById("racha");

const tiempoElemento =
    document.getElementById("tiempo");

const mensajeJuego =
    document.getElementById("mensajeJuego");

const preguntaJuego =
    document.getElementById("preguntaJuego");

const resultadoFinal =
    document.getElementById("resultadoFinal");

const puntajeFinal =
    document.getElementById("puntajeFinal");

const mejorPuntaje =
    document.getElementById("mejorPuntaje");

const btnJugarNuevamente =
    document.getElementById("btnJugarNuevamente");


// ==========================================
// MEZCLAR ARRAY
// ==========================================

function mezclar(array) {

    return [...array].sort(
        () => Math.random() - 0.5
    );

}


// ==========================================
// CARGAR PREGUNTA
// ==========================================

function cargarPregunta() {

    // Limpiar temporizador
    clearInterval(intervalo);

    // Comprobar si terminó
    if (preguntaActual >= 10) {

        terminarJuego();

        return;
    }


    // Elegir película aleatoria
    const pelicula =
        peliculasJuego[
            Math.floor(
                Math.random() * peliculasJuego.length
            )
        ];


    // Mostrar poster
    posterJuego.src =
        pelicula.poster;


    // Limpiar opciones
    opciones.innerHTML = "";

    mensajeJuego.textContent = "";

    mensajeJuego.className =
        "mensaje-juego";


    // Crear respuestas
    let respuestas = [
        pelicula.titulo
    ];


    const otrasPeliculas =
        peliculasJuego.filter(
            item =>
                item.titulo !== pelicula.titulo
        );


    const otras =
        mezclar(otrasPeliculas);


    for (let i = 0; i < 3; i++) {

        respuestas.push(
            otras[i].titulo
        );

    }


    // Mezclar respuestas
    respuestas =
        mezclar(respuestas);


    // Crear botones
    respuestas.forEach(respuesta => {

        const boton =
            document.createElement("button");

        boton.className =
            "opcion";

        boton.textContent =
            respuesta;


        boton.addEventListener(
            "click",
            () => {

                comprobarRespuesta(
                    respuesta,
                    pelicula.titulo,
                    boton
                );

            }
        );


        opciones.appendChild(boton);

    });


    // Iniciar tiempo
    iniciarTemporizador();
}


// ==========================================
// TEMPORIZADOR
// ==========================================

function iniciarTemporizador() {

    tiempo = 10;

    tiempoElemento.textContent =
        tiempo;


    intervalo =
        setInterval(() => {

            tiempo--;

            tiempoElemento.textContent =
                tiempo;


            if (tiempo <= 0) {

                clearInterval(intervalo);

                tiempoAgotado();

            }

        }, 1000);
}


// ==========================================
// COMPROBAR RESPUESTA
// ==========================================

function comprobarRespuesta(
    respuesta,
    correcta,
    boton
) {

    clearInterval(intervalo);


    // Desactivar todos los botones
    const botones =
        document.querySelectorAll(".opcion");


    botones.forEach(
        boton => {
            boton.disabled = true;
        }
    );


    if (respuesta === correcta) {

        boton.classList.add("correcta");

        mensajeJuego.textContent =
            "✓ ¡CORRECTO! +100 puntos";

        mensajeJuego.classList.add(
            "mensaje-correcto"
        );


        puntaje += 100;

        racha++;


    } else {

        boton.classList.add("incorrecta");

        mensajeJuego.textContent =
            `✗ Incorrecto. Era: ${correcta}`;

        mensajeJuego.classList.add(
            "mensaje-error"
        );


        // Mostrar la correcta
        botones.forEach(botonRespuesta => {

            if (
                botonRespuesta.textContent ===
                correcta
            ) {

                botonRespuesta.classList.add(
                    "correcta"
                );

            }

        });


        racha = 0;

    }


    // Actualizar pantalla
    actualizarMarcadores();


    // Siguiente pregunta
    setTimeout(() => {

        preguntaActual++;

        cargarPregunta();

    }, 1500);
}


// ==========================================
// TIEMPO AGOTADO
// ==========================================

function tiempoAgotado() {

    const botones =
        document.querySelectorAll(".opcion");


    botones.forEach(
        boton => {
            boton.disabled = true;
        }
    );


    mensajeJuego.textContent =
        "⏰ ¡Se terminó el tiempo!";


    mensajeJuego.classList.add(
        "mensaje-error"
    );


    racha = 0;

    actualizarMarcadores();


    setTimeout(() => {

        preguntaActual++;

        cargarPregunta();

    }, 1500);
}


// ==========================================
// ACTUALIZAR MARCADORES
// ==========================================

function actualizarMarcadores() {

    puntajeElemento.textContent =
        puntaje;

    rachaElemento.textContent =
        racha;
}


// ==========================================
// FINAL DEL JUEGO
// ==========================================

function terminarJuego() {

    clearInterval(intervalo);


    preguntaJuego.classList.add(
        "oculto"
    );


    resultadoFinal.classList.remove(
        "oculto"
    );


    puntajeFinal.textContent =
        puntaje;


    // Obtener mejor puntuación
    const mejor =
        Number(
            localStorage.getItem(
                "cineMatchMejorPuntaje"
            )
        ) || 0;


    let nuevoMejor = mejor;


    if (puntaje > mejor) {

        nuevoMejor = puntaje;

        localStorage.setItem(
            "cineMatchMejorPuntaje",
            puntaje
        );

    }


    mejorPuntaje.textContent =
        `Mejor puntuación: ${nuevoMejor}`;
}


// ==========================================
// REINICIAR
// ==========================================

function reiniciarJuego() {

    preguntaActual = 0;

    puntaje = 0;

    racha = 0;

    tiempo = 10;


    actualizarMarcadores();


    resultadoFinal.classList.add(
        "oculto"
    );


    preguntaJuego.classList.remove(
        "oculto"
    );


    cargarPregunta();
}


// ==========================================
// BOTÓN JUGAR NUEVAMENTE
// ==========================================

btnJugarNuevamente.addEventListener(
    "click",
    reiniciarJuego
);


// ==========================================
// INICIAR JUEGO
// ==========================================

cargarPregunta();