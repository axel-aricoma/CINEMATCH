/* =====================================================
   LOGIN - CINEMATCH
   ===================================================== */

const loginForm = document.getElementById("loginForm");

const mensaje = document.getElementById("mensaje");


/* =====================================================
   INICIAR SESIÓN
   ===================================================== */

loginForm.addEventListener("submit", function(event) {

    event.preventDefault();


    const email =
        document.getElementById("email").value.trim();

    const password =
        document.getElementById("password").value;


    /* Obtener usuarios */

    const usuarios =
        JSON.parse(localStorage.getItem("cineMatchUsuarios")) || [];


    /* Buscar usuario */

    const usuario = usuarios.find(function(user) {

        return user.email === email &&
               user.password === password;

    });


    /* =================================================
       USUARIO ENCONTRADO
       ================================================= */

    if (usuario) {

    localStorage.setItem(
        "cineMatchUsuarioActivo",
        JSON.stringify(usuario)
    );

    mensaje.textContent =
        "Inicio de sesión correcto.";

    mensaje.style.color = "#4caf50";

    setTimeout(function() {

        window.location.href = "index.html";

    }, 800);

    return;
}


    /* =================================================
        USUARIO NO ENCONTRADO
       ================================================= */

    mensaje.textContent =
        "El correo o la contraseña son incorrectos.";

    mensaje.style.color = "#e01b25";

});