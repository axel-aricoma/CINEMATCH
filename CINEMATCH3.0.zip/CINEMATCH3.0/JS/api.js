
// ==============================
// CONFIGURACIÓN DE APIs
// ==============================
 //credenciales
const TMDB_API_KEY = 'eec0d255ca095d4bc0a8a5c782d27333';
const TMDB_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlZWMwZDI1NWNhMDk1ZDRiYzBhOGE1Yzc4MmQyNzMzMyIsIm5iZiI6MTc4NzMzMDA4Ny4xNzEsInN1YiI6IjZhODg3ZTI3YmM4ZWIxMzllZTE5YTY1MCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.e7ncUP3paeiwhsadCRd2baNQVdpISTI1V1C3xq69zzQ';
const OMDB_API_KEY = '7534ca63';

// ==============================
// CONFIGURACIÓN TMDB
// ==============================

const TMDB_BASE_URL =
    "https://api.themoviedb.org/3";

const TMDB_IMG_URL =
    "https://image.tmdb.org/t/p/w500";


const options = {

    method: "GET",

    headers: {

        accept: "application/json",

        Authorization:
            `Bearer ${TMDB_TOKEN}`

    }

};


// ===============================
// GÉNEROS
// ===============================

const GENRES_MAP = {

    "Acción": 28,

    "Aventura": 12,

    "Animación": 16,

    "Comedia": 35,

    "Crimen": 80,

    "Documental": 99,

    "Drama": 18,

    "Familiar": 10751,

    "Fantasía": 14,

    "Misterio": 9648,

    "Romance": 10749,

    "Ciencia Ficción": 878,

    "Terror": 27,

    "Thriller": 53

};


// ===============================
// PLATAFORMAS TMDB
// ===============================

const PLATFORMS_MAP = {

    "Netflix": 8,

    "Prime Video": 119,

    "Disney+": 337,

    "HBO Max": 1899,

    "Star+": 619

};


// ===============================
// PELÍCULAS POPULARES
// ===============================

async function fetchPopularMovies(page = 1) {

    try {

        const res =
            await fetch(
                `${TMDB_BASE_URL}/movie/popular?language=es-ES&page=${page}`,
                options
            );


        const data =
            await res.json();


        if (!res.ok) {

            console.error(
                "Error TMDB:",
                data
            );

            return [];

        }


        const movies =
            data.results || [];


        return movies.map(movie => {

            movie.media_type =
                "movie";

            return movie;

        });

    }

    catch (error) {

        console.error(
            "Error al obtener películas populares:",
            error
        );

        return [];

    }

}


// ===============================
// BUSCAR PELÍCULAS POR GÉNERO
// ===============================

async function fetchMoviesByGenre(genreId) {

    try {

        const res =
            await fetch(
                `${TMDB_BASE_URL}/discover/movie?with_genres=${genreId}&language=es-ES&sort_by=popularity.desc`,
                options
            );


        const data =
            await res.json();


        if (!res.ok) {

            console.error(
                "Error TMDB:",
                data
            );

            return [];

        }


        const movies =
            data.results || [];


        return movies.map(movie => {

            movie.media_type =
                "movie";

            return movie;

        });

    }

    catch (error) {

        console.error(
            "Error al buscar películas por género:",
            error
        );

        return [];

    }

}


// ===============================
// CONTENIDO POR PLATAFORMA
// ===============================

async function fetchMoviesByPlatform(
    platformId,
    type = "movie"
) {

    try {

        const endpoint =
            type === "tv"
                ? `${TMDB_BASE_URL}/discover/tv`
                : `${TMDB_BASE_URL}/discover/movie`;


        const params =
            new URLSearchParams();


        params.append(
            "language",
            "es-ES"
        );


        params.append(
            "sort_by",
            "popularity.desc"
        );


        params.append(
            "watch_region",
            "AR"
        );


        params.append(
            "with_watch_providers",
            platformId
        );


        params.append(
            "with_watch_monetization_types",
            "flatrate"
        );


        const res =
            await fetch(
                `${endpoint}?${params.toString()}`,
                options
            );


        const data =
            await res.json();


        if (!res.ok) {

            console.error(
                "Error TMDB:",
                data
            );

            return [];

        }


        const resultados =
            data.results || [];


        return resultados.map(item => {

            item.media_type =
                type === "tv"
                    ? "tv"
                    : "movie";

            return item;

        });

    }

    catch (error) {

        console.error(
            "Error al buscar contenido por plataforma:",
            error
        );

        return [];

    }

}


// ======================================================
// CATÁLOGO CON FILTROS COMBINADOS
// ======================================================
//
// ESTA ES LA ÚNICA FUNCIÓN fetchCatalogoFiltrado
// DEL ARCHIVO.
// ======================================================

async function fetchCatalogoFiltrado(
    genreId = null,
    platformId = null,
    type = "all"
) {

    try {

        console.log(
            "========== FETCH CATÁLOGO =========="
        );

        console.log(
            "Género:",
            genreId
        );

        console.log(
            "Plataforma:",
            platformId
        );

        console.log(
            "Tipo:",
            type
        );


        // ==========================================
        // CREAR PARÁMETROS
        // ==========================================

        function crearParametros() {

            const params =
                new URLSearchParams();


            params.append(
                "language",
                "es-ES"
            );


            params.append(
                "sort_by",
                "popularity.desc"
            );


            params.append(
                "watch_region",
                "AR"
            );


            // -------------------------------
            // GÉNERO
            // -------------------------------

            if (
                genreId !== null &&
                genreId !== undefined
            ) {

                params.append(
                    "with_genres",
                    String(genreId)
                );

            }


            // -------------------------------
            // PLATAFORMA
            // -------------------------------

            if (
                platformId !== null &&
                platformId !== undefined
            ) {

                params.append(
                    "with_watch_providers",
                    String(platformId)
                );


                params.append(
                    "with_watch_monetization_types",
                    "flatrate"
                );

            }


            return params;

        }


        // ==========================================
        // BUSCAR PELÍCULAS
        // ==========================================

        async function buscarPeliculas() {

            const params =
                crearParametros();


            const url =
                `${TMDB_BASE_URL}/discover/movie?${params.toString()}`;


            console.log(
                "TMDB PELÍCULAS:",
                url
            );


            const response =
                await fetch(
                    url,
                    options
                );


            const data =
                await response.json();


            if (!response.ok) {

                console.error(
                    "Error TMDB películas:",
                    data
                );

                return [];

            }


            return (
                data.results || []
            ).map(movie => {

                movie.media_type =
                    "movie";

                return movie;

            });

        }


        // ==========================================
        // BUSCAR SERIES
        // ==========================================

        async function buscarSeries() {

            const params =
                crearParametros();


            const url =
                `${TMDB_BASE_URL}/discover/tv?${params.toString()}`;


            console.log(
                "TMDB SERIES:",
                url
            );


            const response =
                await fetch(
                    url,
                    options
                );


            const data =
                await response.json();


            if (!response.ok) {

                console.error(
                    "Error TMDB series:",
                    data
                );

                return [];

            }


            return (
                data.results || []
            ).map(serie => {

                serie.media_type =
                    "tv";

                return serie;

            });

        }


        // ==========================================
        // SOLO PELÍCULAS
        // ==========================================

        if (type === "movie") {

            return await buscarPeliculas();

        }


        // ==========================================
        // SOLO SERIES
        // ==========================================

        if (type === "tv") {

            return await buscarSeries();

        }


        // ==========================================
        // PELÍCULAS + SERIES
        // ==========================================

        const [
            peliculas,
            series
        ] = await Promise.all([

            buscarPeliculas(),

            buscarSeries()

        ]);


        const resultados = [

            ...peliculas,

            ...series

        ];


        // ==========================================
        // ORDENAR POR POPULARIDAD
        // ==========================================

        resultados.sort(
            (a, b) =>
                (b.popularity || 0) -
                (a.popularity || 0)
        );


        return resultados;

    }

    catch (error) {

        console.error(
            "Error en fetchCatalogoFiltrado:",
            error
        );

        return [];

    }

}


// ===============================
// RECOMENDACIONES DEL TEST
// ===============================

async function buscarRecomendaciones(
    preferencias
) {

    try {

        const generos =
            preferencias.generos || [];


        const genreIds =
            generos
                .map(
                    genero =>
                        GENRES_MAP[genero]
                )
                .filter(
                    id => id
                );


        let tipo =
            preferencias.tipo ||
            "ambas";


        let endpoint;


        if (tipo === "serie") {

            endpoint =
                `${TMDB_BASE_URL}/discover/tv`;

        }

        else {

            endpoint =
                `${TMDB_BASE_URL}/discover/movie`;

        }


        const params =
            new URLSearchParams();


        params.append(
            "language",
            "es-ES"
        );


        params.append(
            "sort_by",
            "popularity.desc"
        );


        params.append(
            "page",
            "1"
        );


        // ==========================================
        // GÉNEROS
        // ==========================================

        if (
            genreIds.length > 0
        ) {

            params.append(
                "with_genres",
                genreIds.join("|")
            );

        }


        // ==========================================
        // PELÍCULAS
        // ==========================================

        if (
            tipo === "pelicula"
        ) {

            params.append(
                "vote_count.gte",
                "50"
            );

        }


        const res =
            await fetch(
                `${endpoint}?${params.toString()}`,
                options
            );


        const data =
            await res.json();


        let resultados =
            data.results || [];


        // ==========================================
        // FALLBACK POR GÉNERO
        // ==========================================

        if (
            resultados.length === 0 &&
            genreIds.length > 0
        ) {

            const fallback =
                await fetchMoviesByGenre(
                    genreIds[0]
                );


            resultados =
                fallback;

        }


        // ==========================================
        // FALLBACK POPULARES
        // ==========================================

        if (
            resultados.length === 0
        ) {

            resultados =
                await fetchPopularMovies();

        }


        // ==========================================
        // FILTRO POR EXPERIENCIA
        // ==========================================

        resultados =
            filtrarPorExperiencia(
                resultados,
                preferencias.ambiente
            );


        // ==========================================
        // ORDENAR
        // ==========================================

        resultados.sort(
            (a, b) =>
                (b.popularity || 0) -
                (a.popularity || 0)
        );


        return resultados;

    }

    catch (error) {

        console.error(
            "Error al obtener recomendaciones:",
            error
        );

        return [];

    }

}


// ===============================
// FILTRO POR EXPERIENCIA
// ===============================

function filtrarPorExperiencia(
    resultados,
    ambiente
) {

    // ==========================================
    // SIN AMBIENTE
    // ==========================================

    if (!ambiente) {

        return resultados;

    }


    // ==========================================
    // DIVERTIDO
    // ==========================================

    if (
        ambiente === "divertido"
    ) {

        const resultadosFiltrados =
            resultados.filter(
                movie => {

                    const generos =
                        movie.genre_ids || [];


                    return (

                        generos.includes(35) ||

                        generos.includes(16) ||

                        generos.includes(10751)

                    );

                }
            );


        if (
            resultadosFiltrados.length > 0
        ) {

            return resultadosFiltrados;

        }

    }


    // ==========================================
    // EMOCIÓN
    // ==========================================

    if (
        ambiente === "emocion"
    ) {

        const resultadosFiltrados =
            resultados.filter(
                movie => {

                    const generos =
                        movie.genre_ids || [];


                    return (

                        generos.includes(28) ||

                        generos.includes(12) ||

                        generos.includes(53) ||

                        generos.includes(80)

                    );

                }
            );


        if (
            resultadosFiltrados.length > 0
        ) {

            return resultadosFiltrados;

        }

    }


    // ==========================================
    // MIEDO
    // ==========================================

    if (
        ambiente === "miedo"
    ) {

        const resultadosFiltrados =
            resultados.filter(
                movie => {

                    const generos =
                        movie.genre_ids || [];


                    return (

                        generos.includes(27) ||

                        generos.includes(53) ||

                        generos.includes(9648)

                    );

                }
            );


        if (
            resultadosFiltrados.length > 0
        ) {

            return resultadosFiltrados;

        }

    }


    // ==========================================
    // DEVOLVER RESULTADOS
    // ==========================================

    return resultados;

}

// =========================================
// PLATAFORMAS DONDE SE PUEDE VER
// =========================================

async function fetchWatchProviders(id, tipo = "movie", region = "AR") {

    try {

        const endpoint =
            tipo === "tv"
                ? `${TMDB_BASE_URL}/tv/${id}/watch/providers`
                : `${TMDB_BASE_URL}/movie/${id}/watch/providers`;

        const respuesta = await fetch(
            endpoint,
            options
        );

        if (!respuesta.ok) {

            console.error(
                "Error HTTP plataformas:",
                respuesta.status
            );

            return null;
        }

        const data =
            await respuesta.json();

        console.log(
            "Plataformas encontradas:",
            data.results?.[region]
        );

        return data.results?.[region] || null;

    } catch (error) {

        console.error(
            "Error al obtener plataformas:",
            error
        );

        return null;
    }
}