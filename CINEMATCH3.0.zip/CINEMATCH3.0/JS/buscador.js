// =========================================
// BUSCADOR DE CINE MATCH
// =========================================

const searchInput =
    document.getElementById("searchInput");

const searchButton =
    document.getElementById("searchButton");


// =========================================
// BUSCAR EN TMDB
// =========================================

async function buscarContenido(texto) {

    if (!texto.trim()) {

        cargarPopulares();

        return;
    }


    moviesGrid.innerHTML = `
        <p class="catalog-loading">
            Buscando "${texto}"...
        </p>
    `;


    try {

        const response = await fetch(

            `${TMDB_BASE_URL}/search/multi` +
            `?query=${encodeURIComponent(texto)}` +
            `&language=es-ES` +
            `&page=1`,

            options

        );


        const data =
            await response.json();


        // Dejamos solamente películas y series

        const resultados =
            (data.results || [])
                .filter(item =>
                    item.media_type === "movie" ||
                    item.media_type === "tv"
                );


        catalogTitle.textContent =
            `Resultados para "${texto}"`;


        catalogSubtitle.textContent =
            `${resultados.length} resultado(s) encontrado(s).`;


        renderMovies(resultados);


    } catch (error) {

        console.error(
            "Error en el buscador:",
            error
        );


        moviesGrid.innerHTML = `
            <p class="no-results">
                Ocurrió un error al realizar la búsqueda.
            </p>
        `;

    }

}


// =========================================
// BOTÓN BUSCAR
// =========================================

searchButton.addEventListener(
    "click",
    () => {

        buscarContenido(
            searchInput.value
        );

    }
);


// =========================================
// ENTER PARA BUSCAR
// =========================================

searchInput.addEventListener(
    "keydown",
    event => {

        if (event.key === "Enter") {

            buscarContenido(
                searchInput.value
            );

        }

    }
);