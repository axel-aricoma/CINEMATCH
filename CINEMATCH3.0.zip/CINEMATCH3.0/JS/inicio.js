// ==========================================
// FONDO DINÁMICO DE CINEMATCH
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    cargarFondoPosters
);



// ==========================================
// CARGAR POSTERS
// ==========================================

async function cargarFondoPosters() {

    const contenedor =
        document.getElementById(
            "heroPostersBackground"
        );


    if (!contenedor) {
        return;
    }


    try {

        /*
        ==========================================
        OBTENER PELÍCULAS
        ==========================================
        */

        const peliculas =
            await obtenerMuchasPeliculas();


        /*
        ==========================================
        LIMPIAR CONTENEDOR
        ==========================================
        */

        contenedor.innerHTML = "";


        /*
        ==========================================
        CREAR POSTERS
        ==========================================
        */

        peliculas.forEach(
            pelicula => {

                if (!pelicula.poster_path) {
                    return;
                }


                const imagen =
                    document.createElement("img");


                imagen.src =
                    TMDB_IMG_URL +
                    pelicula.poster_path;


                imagen.alt =
                    pelicula.title ||
                    "Película";


                imagen.loading =
                    "lazy";


                contenedor.appendChild(
                    imagen
                );

            }
        );

    } catch (error) {

        console.error(
            "Error cargando fondo de posters:",
            error
        );

    }

}


// ==========================================
// OBTENER MUCHAS PELÍCULAS
// ==========================================

async function obtenerMuchasPeliculas() {

    const todas = [];


    /*
    ==========================================
    OBTENER VARIAS PÁGINAS
    ==========================================
    */

    for (
        let pagina = 1;
        pagina <= 3;
        pagina++
    ) {

        try {

            const peliculas =
                await fetchPopularMovies(
                    pagina
                );


            if (
                peliculas &&
                peliculas.length > 0
            ) {

                todas.push(
                    ...peliculas
                );

            }

        } catch (error) {

            console.error(
                `Error cargando página ${pagina}:`,
                error
            );

        }

    }


    /*
    ==========================================
    QUEDARNOS CON LOS POSTERS
    ==========================================
    */

    return todas.filter(
        pelicula =>
            pelicula.poster_path
    );

}