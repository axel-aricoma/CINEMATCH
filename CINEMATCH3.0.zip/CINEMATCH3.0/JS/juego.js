// ==========================================
// CINECHALLENGE - PELÍCULAS AUTOMÁTICAS TMDB
// ==========================================

// ==========================================
// VARIABLES DEL JUEGO
// ==========================================

let peliculasJuego = [];

let preguntasPartida = [];

let preguntaActual = 0;
let puntaje = 0;
let racha = 0;
let tiempo = 10;
let intervalo;


// ==========================================
// ELEMENTOS
// ==========================================

const posterJuego =
    document.getElementById("posterJuego");

const opciones =
    document.getElementById("opciones");

const puntajeElemento =
    document.getElementById("puntaje");

const rachaElemento =
    document.getElementById("racha");

const tiempoElemento =
    document.getElementById("tiempo");

const mensajeJuego =
    document.getElementById("mensajeJuego");

const preguntaJuego =
    document.getElementById("preguntaJuego");

const resultadoFinal =
    document.getElementById("resultadoFinal");

const puntajeFinal =
    document.getElementById("puntajeFinal");

const mejorPuntaje =
    document.getElementById("mejorPuntaje");

const btnJugarNuevamente =
    document.getElementById(
        "btnJugarNuevamente"
    );


// ==========================================
// MEZCLAR ARRAY
// ==========================================

function mezclar(array) {

    return [...array].sort(
        () => Math.random() - 0.5
    );

}


// ==========================================
// CARGAR PELÍCULAS DESDE TMDB
// ==========================================

async function cargarPeliculasJuego() {

    try {

        // Comprobamos que api.js esté cargado

        if (
            typeof fetchPopularMovies !==
            "function"
        ) {

            throw new Error(
                "No se encontró fetchPopularMovies(). Verificá que api.js esté cargado antes de juego.js."
            );

        }


        console.log(
            "Cargando películas desde TMDB..."
        );


        // Cargamos varias páginas para
        // tener una lista más grande

        const resultados =
            await Promise.all([

                fetchPopularMovies(1),

                fetchPopularMovies(2),

                fetchPopularMovies(3)

            ]);


        // Unimos todas las películas

        let peliculas = [

            ...(
                resultados[0] || []
            ),

            ...(
                resultados[1] || []
            ),

            ...(
                resultados[2] || []
            )

        ];


        // ======================================
        // ELIMINAR PELÍCULAS SIN POSTER
        // ======================================

        peliculas =
            peliculas.filter(
                pelicula =>

                    pelicula &&
                    pelicula.id &&
                    pelicula.poster_path &&
                    (
                        pelicula.title ||
                        pelicula.name
                    )
            );


        // ======================================
        // ELIMINAR DUPLICADOS
        // ======================================

        const peliculasUnicas =
            new Map();


        peliculas.forEach(
            pelicula => {

                if (
                    !peliculasUnicas.has(
                        pelicula.id
                    )
                ) {

                    peliculasUnicas.set(
                        pelicula.id,
                        pelicula
                    );

                }

            }
        );


        peliculas =
            Array.from(
                peliculasUnicas.values()
            );


        // ======================================
        // CONVERTIR AL FORMATO DEL JUEGO
        // ======================================

        peliculasJuego =
            peliculas.map(
                pelicula => {

                    return {

                        id:
                            pelicula.id,

                        titulo:
                            pelicula.title ||
                            pelicula.name ||
                            "Sin título",

                        poster:
                            TMDB_IMG_URL +
                            pelicula.poster_path

                    };

                }
            );


        // ======================================
        // MEZCLAR PELÍCULAS
        // ======================================

        peliculasJuego =
            mezclar(
                peliculasJuego
            );


        console.log(
            "Películas cargadas para el juego:",
            peliculasJuego
        );


        // ======================================
        // COMPROBAR QUE HAYA SUFICIENTES
        // ======================================

        if (
            peliculasJuego.length < 4
        ) {

            throw new Error(
                "TMDB no devolvió suficientes películas para iniciar el juego."
            );

        }


        // ======================================
        // CREAR PARTIDA
        // ======================================

        prepararPartida();


    } catch (error) {

        console.error(
            "Error cargando películas:",
            error
        );


        mensajeJuego.textContent =
            "No se pudieron cargar las películas desde TMDB.";


        mensajeJuego.classList.add(
            "mensaje-error"
        );


        if (posterJuego) {

            posterJuego.src =
                "https://via.placeholder.com/220x325?text=Error+TMDB";

            posterJuego.classList.remove(
                "poster-pixelado"
            );

        }

    }

}


// ==========================================
// PREPARAR PARTIDA
// ==========================================

function prepararPartida() {

    // Mezclamos todas las películas

    const peliculasMezcladas =
        mezclar(
            peliculasJuego
        );


    // Tomamos 10 películas diferentes

    preguntasPartida =
        peliculasMezcladas.slice(
            0,
            Math.min(
                10,
                peliculasMezcladas.length
            )
        );


    preguntaActual = 0;

    puntaje = 0;

    racha = 0;

    tiempo = 10;


    actualizarMarcadores();


    resultadoFinal.classList.add(
        "oculto"
    );


    preguntaJuego.classList.remove(
        "oculto"
    );


    cargarPregunta();

}


// ==========================================
// CARGAR PREGUNTA
// ==========================================

function cargarPregunta() {

    clearInterval(
        intervalo
    );


    // ======================================
    // COMPROBAR FIN
    // ======================================

    if (
        preguntaActual >=
        preguntasPartida.length
    ) {

        terminarJuego();

        return;

    }


    // ======================================
    // OBTENER PELÍCULA
    // ======================================

    const pelicula =
        preguntasPartida[
            preguntaActual
        ];


    // ======================================
    // MOSTRAR POSTER
    // ======================================

    posterJuego.src =
        pelicula.poster;


    posterJuego.alt =
        `Poster de ${pelicula.titulo}`;


    // ======================================
    // APLICAR EFECTO PIXELADO
    // ======================================

    posterJuego.classList.add(
        "poster-pixelado"
    );


    // ======================================
    // FALLBACK SI EL POSTER FALLA
    // ======================================

    posterJuego.onerror =
        function() {

            this.onerror = null;

            this.classList.remove(
                "poster-pixelado"
            );

            this.src =
                "https://via.placeholder.com/220x325?text=Sin+poster";

        };


    // ======================================
    // LIMPIAR
    // ======================================

    opciones.innerHTML = "";


    mensajeJuego.textContent = "";

    mensajeJuego.className =
        "mensaje-juego";


    // ======================================
    // CREAR RESPUESTAS
    // ======================================

    let respuestas = [

        pelicula

    ];


    // ======================================
    // BUSCAR DISTRACTORES
    // ======================================

    const otrasPeliculas =
        peliculasJuego.filter(
            otraPelicula =>

                otraPelicula.id !==
                pelicula.id

        );


    const distractores =
        mezclar(
            otrasPeliculas
        );


    // Agregamos 3 películas diferentes

    for (
        let i = 0;
        i < 3 &&
        i < distractores.length;
        i++
    ) {

        respuestas.push(
            distractores[i]
        );

    }


    // ======================================
    // MEZCLAR RESPUESTAS
    // ======================================

    respuestas =
        mezclar(
            respuestas
        );


    // ======================================
    // CREAR BOTONES
    // ======================================

    respuestas.forEach(
        respuesta => {

            const boton =
                document.createElement(
                    "button"
                );


            boton.className =
                "opcion";


            boton.textContent =
                respuesta.titulo;


            boton.addEventListener(
                "click",
                function() {

                    comprobarRespuesta(

                        respuesta.id,

                        pelicula.id,

                        boton

                    );

                }
            );


            opciones.appendChild(
                boton
            );

        }
    );


    // ======================================
    // TEMPORIZADOR
    // ======================================

    iniciarTemporizador();

}


// ==========================================
// TEMPORIZADOR
// ==========================================

function iniciarTemporizador() {

    clearInterval(
        intervalo
    );


    tiempo = 10;


    tiempoElemento.textContent =
        tiempo;


    intervalo =
        setInterval(
            () => {

                tiempo--;

                tiempoElemento.textContent =
                    tiempo;


                if (
                    tiempo <= 0
                ) {

                    clearInterval(
                        intervalo
                    );

                    tiempoAgotado();

                }

            },
            1000
        );

}


// ==========================================
// COMPROBAR RESPUESTA
// ==========================================

function comprobarRespuesta(
    respuestaId,
    correctaId,
    boton
) {

    clearInterval(
        intervalo
    );


    // ======================================
    // REVELAR POSTER
    // ======================================

    posterJuego.classList.remove(
        "poster-pixelado"
    );


    // ======================================
    // DESACTIVAR BOTONES
    // ======================================

    const botones =
        document.querySelectorAll(
            ".opcion"
        );


    botones.forEach(
        botonRespuesta => {

            botonRespuesta.disabled =
                true;

        }
    );


    // ======================================
    // COMPROBAR
    // ======================================

    if (
        respuestaId ===
        correctaId
    ) {

        boton.classList.add(
            "correcta"
        );


        mensajeJuego.textContent =
            "✓ ¡CORRECTO! +100 puntos";


        mensajeJuego.classList.add(
            "mensaje-correcto"
        );


        puntaje += 100;


        racha++;


    } else {

        boton.classList.add(
            "incorrecta"
        );


        const peliculaCorrecta =
            peliculasJuego.find(
                pelicula =>
                    pelicula.id ===
                    correctaId
            );


        mensajeJuego.textContent =
            `✗ Incorrecto. Era: ${peliculaCorrecta.titulo}`;


        mensajeJuego.classList.add(
            "mensaje-error"
        );


        // Buscar el botón correcto

        botones.forEach(
            botonRespuesta => {

                if (
                    botonRespuesta.textContent ===
                    peliculaCorrecta.titulo
                ) {

                    botonRespuesta.classList.add(
                        "correcta"
                    );

                }

            }
        );


        racha = 0;

    }


    actualizarMarcadores();


    // ======================================
    // SIGUIENTE PREGUNTA
    // ======================================

    setTimeout(
        () => {

            preguntaActual++;

            cargarPregunta();

        },
        1500
    );

}


// ==========================================
// TIEMPO AGOTADO
// ==========================================

function tiempoAgotado() {

    // ======================================
    // REVELAR POSTER
    // ======================================

    posterJuego.classList.remove(
        "poster-pixelado"
    );


    const botones =
        document.querySelectorAll(
            ".opcion"
        );


    botones.forEach(
        boton => {

            boton.disabled =
                true;

        }
    );


    const peliculaCorrecta =
        preguntasPartida[
            preguntaActual
        ];


    mensajeJuego.textContent =
        `⏰ ¡Se terminó el tiempo! Era: ${peliculaCorrecta.titulo}`;


    mensajeJuego.classList.add(
        "mensaje-error"
    );


    racha = 0;


    actualizarMarcadores();


    setTimeout(
        () => {

            preguntaActual++;

            cargarPregunta();

        },
        1500
    );

}


// ==========================================
// ACTUALIZAR MARCADORES
// ==========================================

function actualizarMarcadores() {

    puntajeElemento.textContent =
        puntaje;


    rachaElemento.textContent =
        racha;

}


// ==========================================
// FINAL DEL JUEGO
// ==========================================

function terminarJuego() {

    clearInterval(
        intervalo
    );


    // Quitar pixelado al terminar

    if (posterJuego) {

        posterJuego.classList.remove(
            "poster-pixelado"
        );

    }


    preguntaJuego.classList.add(
        "oculto"
    );


    resultadoFinal.classList.remove(
        "oculto"
    );


    puntajeFinal.textContent =
        puntaje;


    // ======================================
    // MEJOR PUNTAJE
    // ======================================

    const mejor =
        Number(
            localStorage.getItem(
                "cineMatchMejorPuntaje"
            )
        ) || 0;


    let nuevoMejor =
        mejor;


    if (
        puntaje > mejor
    ) {

        nuevoMejor =
            puntaje;


        localStorage.setItem(
            "cineMatchMejorPuntaje",
            puntaje
        );

    }


    mejorPuntaje.textContent =
        `Mejor puntuación: ${nuevoMejor}`;

}


// ==========================================
// REINICIAR JUEGO
// ==========================================

async function reiniciarJuego() {

    clearInterval(
        intervalo
    );


    preguntaActual = 0;

    puntaje = 0;

    racha = 0;

    tiempo = 10;


    // Volver a aplicar el efecto
    // cuando aparezca la primera pregunta

    if (posterJuego) {

        posterJuego.classList.remove(
            "poster-pixelado"
        );

    }


    actualizarMarcadores();


    resultadoFinal.classList.add(
        "oculto"
    );


    preguntaJuego.classList.remove(
        "oculto"
    );


    // ======================================
    // VOLVER A MEZCLAR LAS PELÍCULAS
    // ======================================

    prepararPartida();

}


// ==========================================
// BOTÓN JUGAR NUEVAMENTE
// ==========================================

btnJugarNuevamente.addEventListener(
    "click",
    reiniciarJuego
);


// ==========================================
// INICIAR JUEGO
// ==========================================

async function iniciarJuego() {

    // Mostrar estado de carga

    mensajeJuego.textContent =
        "Cargando películas...";


    mensajeJuego.className =
        "mensaje-juego";


    if (posterJuego) {

        posterJuego.classList.remove(
            "poster-pixelado"
        );


        posterJuego.src =
            "https://via.placeholder.com/220x325?text=Cargando...";

    }


    // Desactivar opciones mientras carga

    opciones.innerHTML = "";


    await cargarPeliculasJuego();

}


// ==========================================
// ARRANCAR
// ==========================================

iniciarJuego();