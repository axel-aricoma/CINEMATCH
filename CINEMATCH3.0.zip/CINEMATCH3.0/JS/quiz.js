// ===============================
// CONFIGURACIÓN DEL TEST
// ===============================

let currentStep = 1;

const totalSteps = 5;


// ===============================
// ELEMENTOS DEL HTML
// ===============================

const btnNext =
    document.getElementById('btnNext');

const btnBack =
    document.getElementById('btnBack');

const quizForm =
    document.getElementById('quizForm');

const resultContainer =
    document.getElementById('resultContainer');

const progressFill =
    document.getElementById('progressFill');

const stepIndicator =
    document.getElementById('stepIndicator');


// ===============================
// CAMBIAR DE PASO
// ===============================

function updateQuizView() {

    document
        .querySelectorAll('.quiz-step')
        .forEach(step => {

            step.style.display = 'none';

            if (
                parseInt(step.dataset.step)
                === currentStep
            ) {

                step.style.display = 'block';

            }

        });


    // Barra de progreso

    progressFill.style.width =
        `${(currentStep / totalSteps) * 100}%`;


    // Texto del paso

    stepIndicator.textContent =
        `PASO ${currentStep} DE ${totalSteps}`;


    // Botón atrás

    btnBack.disabled =
        currentStep === 1;


    btnBack.style.opacity =
        currentStep === 1
            ? '0.5'
            : '1';


    // Botón siguiente

    if (currentStep === totalSteps) {

        btnNext.innerHTML =
            'OBTENER RECOMENDACIÓN <i class="fa-solid fa-wand-magic-sparkles"></i>';

    } else {

        btnNext.innerHTML =
            'SIGUIENTE <i class="fa-solid fa-chevron-right"></i>';

    }

}


// ===============================
// BOTÓN SIGUIENTE
// ===============================

btnNext.addEventListener(
    'click',
    async () => {

        if (currentStep < totalSteps) {

            currentStep++;

            updateQuizView();

        } else {

            await obtenerRecomendacion();

        }

    }
);


// ===============================
// BOTÓN ATRÁS
// ===============================

btnBack.addEventListener(
    'click',
    () => {

        if (currentStep > 1) {

            currentStep--;

            updateQuizView();

        }

    }
);


// ===============================
// OBTENER RESPUESTAS
// ===============================

function obtenerPreferencias() {


    // -------------------------------
    // PLATAFORMAS
    // -------------------------------

    const plataformas =
        Array.from(
            document.querySelectorAll(
                'input[name="plataforma"]:checked'
            )
        ).map(input => input.value);


    // -------------------------------
    // GÉNEROS
    // -------------------------------

    const generos =
        Array.from(
            document.querySelectorAll(
                'input[name="genero"]:checked'
            )
        ).map(input => input.value);


    // -------------------------------
    // TIEMPO
    // -------------------------------

    const tiempoInput =
        document.querySelector(
            'input[name="tiempo"]:checked'
        );

    const tiempo =
        tiempoInput
            ? tiempoInput.value
            : 'medio';


    // -------------------------------
    // EXPERIENCIA
    // -------------------------------

    const ambienteInput =
        document.querySelector(
            'input[name="ambiente"]:checked'
        );

    const ambiente =
        ambienteInput
            ? ambienteInput.value
            : 'emocion';


    // -------------------------------
    // PELÍCULA / SERIE
    // -------------------------------

    const tipoInput =
        document.querySelector(
            'input[name="tipo"]:checked'
        );

    const tipo =
        tipoInput
            ? tipoInput.value
            : 'ambas';


    return {

        plataformas,

        generos,

        tiempo,

        ambiente,

        tipo

    };

}


// ===============================
// OBTENER RECOMENDACIÓN
// ===============================

async function obtenerRecomendacion() {

    // Ocultar formulario

    quizForm.style.display =
        'none';


    // Ocultar encabezado

    const quizHeader =
        document.querySelector(
            '.quiz-header'
        );

    if (quizHeader) {

        quizHeader.style.display =
            'none';

    }


    // Mostrar resultado

    resultContainer.style.display =
        'block';


    // Mostrar mensaje mientras carga

    document.getElementById(
        'resultTitle'
    ).textContent =
        'Buscando tu recomendación...';


    document.getElementById(
        'resultDesc'
    ).textContent =
        'Estamos analizando tus preferencias.';


    /*
    ==========================================
    OBTENER PREFERENCIAS
    ==========================================
    */

    const preferencias =
        obtenerPreferencias();


    console.log(
        'Preferencias seleccionadas:',
        preferencias
    );


    /*
    ==========================================
    CONSULTAR TMDB
    ==========================================
    */

    const resultados =
        await buscarRecomendaciones(
            preferencias
        );


    /*
    ==========================================
    SI NO HAY RESULTADOS
    ==========================================
    */

    if (
        !resultados ||
        resultados.length === 0
    ) {

        mostrarSinResultados();

        return;

    }


    /*
    ==========================================
    ELEGIR RECOMENDACIÓN
    ==========================================
    */

    const cantidad =
        Math.min(
            resultados.length,
            10
        );


    const indice =
        Math.floor(
            Math.random() * cantidad
        );


    const match =
        resultados[indice];


    /*
    ==========================================
    MOSTRAR RESULTADO
    ==========================================
    */

    mostrarResultado(match);

}


// ===============================
// MOSTRAR RESULTADO
// ===============================

function mostrarResultado(movie) {

    /*
    Para películas TMDB utiliza "title".

    Para series utiliza "name".
    */

    const titulo =
        movie.title ||
        movie.name ||
        'Título desconocido';


    const fecha =
        movie.release_date ||
        movie.first_air_date ||
        '';


    const año =
        fecha
            ? fecha.split('-')[0]
            : '';


    const descripcion =
        movie.overview ||
        'Sin información detallada disponible.';


    const imagen =
        movie.poster_path
            ? TMDB_IMG_URL + movie.poster_path
            : 'https://via.placeholder.com/500x750?text=Sin+Poster';


    /*
    ==========================================
    INSERTAR DATOS
    ==========================================
    */

    document.getElementById(
        'resultTitle'
    ).textContent =
        titulo;


    document.getElementById(
        'resultDesc'
    ).textContent =
        descripcion;


    document.getElementById(
        'resultYear'
    ).textContent =
        año;


    document.getElementById(
        'resultImg'
    ).src =
        imagen;

}


// ===============================
// SIN RESULTADOS
// ===============================

function mostrarSinResultados() {

    document.getElementById(
        'resultTitle'
    ).textContent =
        'No encontramos una recomendación';


    document.getElementById(
        'resultDesc'
    ).textContent =
        'Probá cambiando alguno de los géneros o preferencias del test.';


    document.getElementById(
        'resultYear'
    ).textContent =
        '';


    document.getElementById(
        'resultImg'
    ).src =
        'https://via.placeholder.com/500x750?text=Sin+Resultado';

}


// ===============================
// LIMITAR GÉNEROS A 3
// ===============================

const genreCheckboxes =
    document.querySelectorAll(
        'input[name="genero"]'
    );


genreCheckboxes.forEach(
    checkbox => {

        checkbox.addEventListener(
            'change',
            () => {

                const selected =
                    document.querySelectorAll(
                        'input[name="genero"]:checked'
                    );


                if (
                    selected.length > 3
                ) {

                    checkbox.checked =
                        false;


                    alert(
                        'Solamente podés elegir hasta 3 géneros.'
                    );

                }

            }
        );

    }
);


// ===============================
// INICIAR TEST
// ===============================

updateQuizView();