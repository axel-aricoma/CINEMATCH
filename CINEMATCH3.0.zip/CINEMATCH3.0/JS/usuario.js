// ==========================================
// USUARIO Y SESIÓN
// ==========================================

const USUARIO_ACTIVO = "cineMatchUsuarioActivo";


// ==========================================
// ACTUALIZAR NAVBAR
// ==========================================

function actualizarUsuarioNav() {

    const usuarioNav =
        document.getElementById("usuarioNav");

    if (!usuarioNav) return;


    const usuarioActivo =
        localStorage.getItem(USUARIO_ACTIVO);


    // ==========================================
    // NO HAY USUARIO CONECTADO
    // ==========================================

    if (!usuarioActivo) {

        usuarioNav.innerHTML = `
            <a
                href="login.html"
                class="btn-login"
            >
                <i class="fa-regular fa-user"></i>
                Iniciar sesión
            </a>
        `;

        return;
    }


    // ==========================================
    // OBTENER USUARIO
    // ==========================================

    let usuario;

    try {

        usuario =
            JSON.parse(usuarioActivo);

    } catch (error) {

        console.error(
            "Error al leer el usuario:",
            error
        );

        localStorage.removeItem(
            USUARIO_ACTIVO
        );

        return;
    }


    // ==========================================
    // NOMBRE DEL USUARIO
    // ==========================================

    const nombre =
        usuario.usuario || "Usuario";


    // ==========================================
    // FOTO DE PERFIL
    // ==========================================

    /*
        perfil.js guarda la foto en:

        cineMatchFotoPerfil
    */

    const fotoGuardada =
        localStorage.getItem(
            "cineMatchFotoPerfil"
        );


    let avatarHTML;


    if (fotoGuardada) {

        avatarHTML = `
            <img
                src="${fotoGuardada}"
                alt="Foto de perfil"
                class="nav-profile-photo"
            >
        `;

    } else {

        /*
            Si todavía no hay foto,
            mostramos la primera letra
            del nombre.
        */

        const inicial =
            nombre
                .charAt(0)
                .toUpperCase();


        avatarHTML = `
            <div class="nav-profile-placeholder">
                ${inicial}
            </div>
        `;
    }


    // ==========================================
    // CREAR PERFIL DEL NAVBAR
    // ==========================================

    usuarioNav.innerHTML = `

        <div
            class="usuario-menu"
            id="usuarioMenu"
        >

            <button
                class="usuario-btn"
                id="usuarioBtn"
                type="button"
            >

                ${avatarHTML}

                <span class="usuario-nombre">
                    ${nombre}
                </span>

                <i
                    class="fa-solid fa-chevron-down usuario-flecha"
                ></i>

            </button>


            <div
                id="menuUsuario"
                class="menu-usuario oculto"
            >

                <a href="perfil.html">

                    <i class="fa-regular fa-user"></i>

                    Mi perfil

                </a>


                <button
                    type="button"
                    id="btnCerrarSesionNav"
                >

                    <i
                        class="fa-solid fa-right-from-bracket"
                    ></i>

                    Cerrar sesión

                </button>

            </div>

        </div>

    `;


    // ==========================================
    // BOTÓN DEL USUARIO
    // ==========================================

    const usuarioBtn =
        document.getElementById(
            "usuarioBtn"
        );


    const menuUsuario =
        document.getElementById(
            "menuUsuario"
        );


    if (
        usuarioBtn &&
        menuUsuario
    ) {

        usuarioBtn.addEventListener(
            "click",
            function(event) {

                event.stopPropagation();

                menuUsuario.classList.toggle(
                    "oculto"
                );

                usuarioBtn.classList.toggle(
                    "abierto"
                );

            }
        );

    }


    // ==========================================
    // CERRAR MENÚ AL HACER CLICK AFUERA
    // ==========================================

    document.addEventListener(
        "click",
        function(event) {

            const usuarioMenu =
                document.getElementById(
                    "usuarioMenu"
                );


            if (
                usuarioMenu &&
                !usuarioMenu.contains(
                    event.target
                )
            ) {

                menuUsuario.classList.add(
                    "oculto"
                );

                usuarioBtn.classList.remove(
                    "abierto"
                );

            }

        }
    );


    // ==========================================
    // CERRAR SESIÓN DESDE EL NAVBAR
    // ==========================================

    const botonCerrar =
        document.getElementById(
            "btnCerrarSesionNav"
        );


    if (botonCerrar) {

        botonCerrar.addEventListener(
            "click",
            function(event) {

                event.stopPropagation();

                cerrarSesion();

            }
        );

    }

}


// ==========================================
// CERRAR SESIÓN
// ==========================================

function cerrarSesion() {

    // Guardamos el tiempo antes de cerrar

    registrarTiempoUso();


    // Eliminamos la sesión

    localStorage.removeItem(
        USUARIO_ACTIVO
    );


    // Volvemos al inicio

    window.location.href =
        "index.html";
}


// ==========================================
// TIEMPO DE USO
// ==========================================

let momentoInicio =
    Date.now();


// ==========================================
// REGISTRAR TIEMPO UTILIZADO
// ==========================================

function registrarTiempoUso() {

    const usuarioActivo =
        localStorage.getItem(
            USUARIO_ACTIVO
        );


    if (!usuarioActivo) return;


    const ahora =
        Date.now();


    const tiempoSesion =
        Math.floor(
            (ahora - momentoInicio) / 1000
        );


    if (tiempoSesion <= 0) return;


    const tiempoAnterior =
        Number(
            localStorage.getItem(
                "cineMatchTiempoUso"
            )
        ) || 0;


    const nuevoTiempo =
        tiempoAnterior +
        tiempoSesion;


    localStorage.setItem(
        "cineMatchTiempoUso",
        nuevoTiempo
    );


    momentoInicio =
        ahora;
}


// ==========================================
// REGISTRAR TIEMPO CADA 30 SEGUNDOS
// ==========================================

setInterval(() => {

    registrarTiempoUso();

}, 30000);


// ==========================================
// CUANDO SE ABANDONA LA PÁGINA
// ==========================================

window.addEventListener(
    "beforeunload",
    () => {

        registrarTiempoUso();

    }
);


// ==========================================
// INICIO
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    () => {

        actualizarUsuarioNav();

    }
);


/* ==========================================
   SUBRAYADO ACTIVO DEL NAVBAR
   ========================================== */

document.addEventListener("DOMContentLoaded", function () {

    // Obtener el nombre del archivo actual
    const paginaActual = window.location.pathname
        .split("/")
        .pop()
        .toLowerCase();

    // Relacionar cada página con su enlace
    const paginasNavbar = {
        "index.html": "index.html",
        "gustos.html": "gustos.html",
        "catalogo.html": "catalogo.html",
        "pelicula.html": "catalogo.html",
        "juego.html": "juego.html",
        "nosotros.html": "nosotros.html"
    };

    // Buscar todos los enlaces del menú
    const enlaces = document.querySelectorAll(
        ".nav-links a"
    );

    // Quitar el subrayado anterior
    enlaces.forEach(function (enlace) {
        enlace.classList.remove("active");
    });

    // Buscar cuál corresponde a la página actual
    const paginaActiva = paginasNavbar[paginaActual];

    if (paginaActiva) {
        enlaces.forEach(function (enlace) {

            const destino = enlace.getAttribute("href");

            if (destino === paginaActiva) {
                enlace.classList.add("active");
            }

        });
    }

});