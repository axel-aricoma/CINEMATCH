// ==========================================
// ELEMENTOS DEL HTML
// ==========================================

const moviesGrid =
    document.getElementById("moviesGrid");

const genreList =
    document.getElementById("genreList");

const typeButtons =
    document.querySelectorAll(".type-btn");

const platformButtons =
    document.querySelectorAll(".platform-btn");

const catalogTitle =
    document.getElementById("catalogTitle");

const catalogSubtitle =
    document.getElementById("catalogSubtitle");


// ==========================================
// FILTROS ACTUALES
// ==========================================

let currentGenre = "all";

let currentType = "all";

let currentPlatform = null;


// ==========================================
// MOSTRAR RESULTADOS
// ==========================================

function renderMovies(movies) {

    if (!movies || movies.length === 0) {

        moviesGrid.innerHTML = `
            <p class="no-results">
                No se encontraron películas o series.
            </p>
        `;

        return;
    }


    moviesGrid.innerHTML = movies.map(movie => {

        const title =
            movie.title ||
            movie.name ||
            "Sin título";


        const date =
            movie.release_date ||
            movie.first_air_date ||
            "";


        const year =
            date
                ? date.split("-")[0]
                : "S/D";


        const tipo =
            movie.media_type === "tv"
                ? "tv"
                : "movie";


        const tipoTexto =
            tipo === "tv"
                ? "Serie"
                : "Película";


        const poster =
            movie.poster_path
                ? TMDB_IMG_URL + movie.poster_path
                : "https://via.placeholder.com/500x750?text=No+Poster";


        const rating =
            movie.vote_average
                ? movie.vote_average.toFixed(1)
                : "N/A";


        return `

            <article
                class="movie-card"
                onclick="abrirPelicula(${movie.id}, '${tipo}')"
            >

                <div class="poster-container">

                    <img
                        src="${poster}"
                        alt="${title}"
                    >

                    <div class="rating-badge">

                        <i class="fa-solid fa-star"></i>

                        ${rating}

                    </div>

                </div>


                <div class="movie-info">

                    <h3 class="movie-title">

                        ${title}

                    </h3>


                    <span class="movie-meta">

                        ${year} • ${tipoTexto}

                    </span>


                    <p class="movie-description">

                        ${
                            movie.overview ||
                            "Sin descripción disponible."
                        }

                    </p>

                </div>

            </article>

        `;

    }).join("");

}


// ==========================================
// APLICAR FILTROS
// ==========================================

async function aplicarFiltros() {

    console.log(
        "APLICANDO:",
        currentGenre,
        currentPlatform,
        currentType
    );


    moviesGrid.innerHTML = `

        <p class="catalog-loading">

            Buscando contenido...

        </p>

    `;


    // ==========================================
    // CONVERTIR GÉNERO A ID
    // ==========================================

    let genreId = null;


    if (
        currentGenre &&
        currentGenre !== "all"
    ) {

        genreId =
            GENRES_MAP[currentGenre];

    }


    // ==========================================
    // CONVERTIR PLATAFORMA A ID
    // ==========================================

    let platformId = null;


    if (currentPlatform) {

        platformId =
            PLATFORMS_MAP[currentPlatform];

    }


    // ==========================================
    // CONSULTAR TMDB
    // ==========================================

    const resultados =
        await fetchCatalogoFiltrado(

            genreId,

            platformId,

            currentType

        );


    // ==========================================
    // TÍTULO
    // ==========================================

    let partes = [];


    if (currentPlatform) {

        partes.push(
            currentPlatform
        );

    }


    if (
        currentGenre &&
        currentGenre !== "all"
    ) {

        partes.push(
            currentGenre
        );

    }


    if (currentType === "movie") {

        partes.push("Películas");

    }


    if (currentType === "tv") {

        partes.push("Series");

    }


    if (partes.length > 0) {

        catalogTitle.textContent =
            partes.join(" • ");

        catalogSubtitle.textContent =
            "Resultados según los filtros seleccionados.";

    }
    else {

        catalogTitle.textContent =
            "Películas populares";

        catalogSubtitle.textContent =
            "Descubrí las películas más populares.";

    }


    renderMovies(resultados);

}


// ==========================================
// GÉNEROS
// ==========================================

if (genreList) {

    genreList.addEventListener(
        "click",
        async function(event) {

            const li =
                event.target.closest("li");


            if (!li) return;


            // Quitar activo
            document
                .querySelectorAll(
                    "#genreList li"
                )
                .forEach(item => {

                    item.classList.remove(
                        "active"
                    );

                });


            // Activar seleccionado
            li.classList.add("active");


            currentGenre =
                li.dataset.genre;


            await aplicarFiltros();

        }
    );

}


// ==========================================
// TIPO
// ==========================================

typeButtons.forEach(button => {

    button.addEventListener(
        "click",
        async function() {


            typeButtons.forEach(btn => {

                btn.classList.remove(
                    "active"
                );

            });


            button.classList.add(
                "active"
            );


            currentType =
                button.dataset.type;


            console.log(
                "TIPO SELECCIONADO:",
                currentType
            );


            await aplicarFiltros();

        }
    );

});


// ==========================================
// PLATAFORMAS
// ==========================================

platformButtons.forEach(button => {

    button.addEventListener(
        "click",
        async function() {


            const plataforma =
                button.dataset.platform;


            // Si vuelve a tocar la misma,
            // se desactiva

            if (
                currentPlatform ===
                plataforma
            ) {

                currentPlatform = null;

                button.classList.remove(
                    "active"
                );

            }

            else {


                platformButtons.forEach(btn => {

                    btn.classList.remove(
                        "active"
                    );

                });


                button.classList.add(
                    "active"
                );


                currentPlatform =
                    plataforma;

            }


            console.log(
                "PLATAFORMA:",
                currentPlatform
            );


            await aplicarFiltros();

        }
    );

});


// ==========================================
// ABRIR PELÍCULA / SERIE
// ==========================================

function abrirPelicula(
    id,
    tipo
) {

    window.location.href =
        `pelicula.html?id=${id}&tipo=${tipo}`;

}


// ==========================================
// CATÁLOGO INICIAL
// ==========================================

async function cargarCatalogoInicial() {


    currentGenre = "all";

    currentType = "all";

    currentPlatform = null;


    // Limpiar géneros

    document
        .querySelectorAll(
            "#genreList li"
        )
        .forEach(item => {

            item.classList.remove(
                "active"
            );

        });


    const allGenre =
        document.querySelector(
            '#genreList li[data-genre="all"]'
        );


    if (allGenre) {

        allGenre.classList.add(
            "active"
        );

    }


    // Limpiar tipos

    typeButtons.forEach(button => {

        button.classList.remove(
            "active"
        );

    });


    const allType =
        document.querySelector(
            '.type-btn[data-type="all"]'
        );


    if (allType) {

        allType.classList.add(
            "active"
        );

    }


    // Limpiar plataformas

    platformButtons.forEach(button => {

        button.classList.remove(
            "active"
        );

    });


    moviesGrid.innerHTML = `

        <p class="catalog-loading">

            Cargando catálogo...

        </p>

    `;


    const peliculas =
        await fetchPopularMovies();


    catalogTitle.textContent =
        "Películas populares";


    catalogSubtitle.textContent =
        "Descubrí las películas más populares.";


    renderMovies(peliculas);

}


// ==========================================
// INICIAR
// ==========================================

cargarCatalogoInicial();