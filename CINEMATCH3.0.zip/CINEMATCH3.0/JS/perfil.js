// ==========================================
// PERFIL DE USUARIO
// ==========================================

document.addEventListener("DOMContentLoaded", () => {

    const usuarioActivo =
        localStorage.getItem("cineMatchUsuarioActivo");

    // Si no hay usuario conectado
    if (!usuarioActivo) {
        window.location.href = "login.html";
        return;
    }

    const usuario = JSON.parse(usuarioActivo);

    cargarDatosUsuario(usuario);
    cargarEstadisticas();
    cargarContenido();
    cargarGeneros();
    cargarTiempoUso();
    configurarFotoPerfil();
    configurarCerrarSesion();
});


// ==========================================
// DATOS DEL USUARIO
// ==========================================

function cargarDatosUsuario(usuario) {

    const nombre = document.getElementById("nombreUsuario");
    const correo = document.getElementById("correoUsuario");
    const fecha = document.getElementById("fechaRegistro");

    if (nombre) {
        nombre.textContent = usuario.usuario;
    }

    if (correo) {
        correo.textContent = usuario.email;
    }

    if (fecha && usuario.fechaRegistro) {

        const fechaFormateada =
            new Date(usuario.fechaRegistro).toLocaleDateString(
                "es-AR"
            );

        fecha.textContent =
            `Miembro desde: ${fechaFormateada}`;
    }
}


// ==========================================
// TIEMPO DE USO
// ==========================================

function cargarTiempoUso() {

    const elemento =
        document.getElementById("tiempoUso");

    if (!elemento) return;

    const segundos =
        Number(
            localStorage.getItem("cineMatchTiempoUso")
        ) || 0;

    const horas = Math.floor(segundos / 3600);

    const minutos =
        Math.floor((segundos % 3600) / 60);

    if (horas > 0) {

        elemento.textContent =
            `${horas} h ${minutos} min`;

    } else {

        elemento.textContent =
            `${minutos} minutos`;
    }
}


// ==========================================
// ESTADÍSTICAS
// ==========================================

function cargarEstadisticas() {

    const favoritos =
        JSON.parse(
            localStorage.getItem("cineMatchFavoritos")
        ) || [];

    const quieroVer =
        JSON.parse(
            localStorage.getItem("cineMatchQuieroVer")
        ) || [];

    const vistos =
        JSON.parse(
            localStorage.getItem("cineMatchVistos")
        ) || [];


    const cantidadFavoritos =
        document.getElementById("cantidadFavoritos");

    const cantidadQuieroVer =
        document.getElementById("cantidadQuieroVer");

    const cantidadVistos =
        document.getElementById("cantidadVistos");


    if (cantidadFavoritos) {
        cantidadFavoritos.textContent =
            favoritos.length;
    }

    if (cantidadQuieroVer) {
        cantidadQuieroVer.textContent =
            quieroVer.length;
    }

    if (cantidadVistos) {
        cantidadVistos.textContent =
            vistos.length;
    }
}


// ==========================================
// CONTENIDO
// ==========================================

function cargarContenido() {

    const favoritos =
        JSON.parse(
            localStorage.getItem("cineMatchFavoritos")
        ) || [];

    const quieroVer =
        JSON.parse(
            localStorage.getItem("cineMatchQuieroVer")
        ) || [];

    const vistos =
        JSON.parse(
            localStorage.getItem("cineMatchVistos")
        ) || [];


    mostrarPeliculas(
        favoritos,
        "favoritosGrid"
    );

    mostrarPeliculas(
        quieroVer,
        "quieroVerGrid"
    );

    mostrarPeliculas(
        vistos,
        "vistosGrid"
    );
}


// ==========================================
// MOSTRAR PELÍCULAS
// ==========================================

function mostrarPeliculas(lista, contenedorId) {

    const contenedor =
        document.getElementById(contenedorId);

    if (!contenedor) return;

    contenedor.innerHTML = "";


    if (lista.length === 0) {

        contenedor.innerHTML = `
            <p class="vacio">
                No hay contenido todavía.
            </p>
        `;

        return;
    }


    lista.forEach(item => {

        const tarjeta =
            document.createElement("div");

        tarjeta.className =
            "pelicula-card";


        const imagen =
            item.poster
                ? item.poster
                : "https://via.placeholder.com/300x450?text=Sin+imagen";


        tarjeta.innerHTML = `
            <img
                src="${imagen}"
                alt="${item.titulo || "Película"}"
            >

            <div class="pelicula-info">

                <h3>
                    ${item.titulo || "Sin título"}
                </h3>

                <p>
                    ${item.año || ""}
                </p>

            </div>
        `;


        tarjeta.addEventListener("click", () => {

            window.location.href =
                `pelicula.html?id=${item.id}&tipo=${item.tipo}`;

        });


        contenedor.appendChild(tarjeta);

    });
}


// ==========================================
// GÉNEROS MÁS VISTOS
// ==========================================

function cargarGeneros() {

    const contenedor =
        document.getElementById("generosGrid");

    if (!contenedor) return;


    const vistos =
        JSON.parse(
            localStorage.getItem("cineMatchVistos")
        ) || [];


    if (vistos.length === 0) {

        contenedor.innerHTML = `
            <p class="vacio">
                Todavía no tenés películas vistas.
            </p>
        `;

        return;
    }


    const contador = {};


    vistos.forEach(pelicula => {

        if (!pelicula.generos) return;

        pelicula.generos.forEach(genero => {

            if (!contador[genero]) {
                contador[genero] = 0;
            }

            contador[genero]++;

        });

    });


    const generosOrdenados =
        Object.entries(contador)
            .sort((a, b) => b[1] - a[1]);


    contenedor.innerHTML = "";


    generosOrdenados.forEach(
        ([genero, cantidad]) => {

            const elemento =
                document.createElement("div");

            elemento.className =
                "genero-estadistica";

            elemento.innerHTML = `
                <span>${genero}</span>
                <strong>${cantidad}</strong>
            `;

            contenedor.appendChild(elemento);

        }
    );
}


// ==========================================
// FOTO DE PERFIL
// ==========================================

function configurarFotoPerfil() {

    const foto =
        document.getElementById("fotoPerfil");

    const input =
        document.getElementById("cambiarFoto");


    if (!foto || !input) return;


    const fotoGuardada =
        localStorage.getItem("cineMatchFotoPerfil");


    if (fotoGuardada) {
        foto.src = fotoGuardada;
    }


    input.addEventListener("change", function () {

        const archivo = this.files[0];

        if (!archivo) return;


        const lector =
            new FileReader();


        lector.onload = function (evento) {

            const imagen =
                evento.target.result;

            foto.src = imagen;

            localStorage.setItem(
                "cineMatchFotoPerfil",
                imagen
            );
        };


        lector.readAsDataURL(archivo);

    });
}


// ==========================================
// CERRAR SESIÓN
// ==========================================

function configurarCerrarSesion() {

    const boton =
        document.getElementById("btnCerrarSesion");

    if (!boton) return;


    boton.addEventListener("click", () => {

        if (typeof registrarTiempoUso === "function") {
            registrarTiempoUso();
        }

        localStorage.removeItem(
            "cineMatchUsuarioActivo"
        );

        window.location.href =
            "index.html";
    });
}