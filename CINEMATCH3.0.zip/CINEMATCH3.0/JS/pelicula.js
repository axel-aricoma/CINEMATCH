// =========================================
// DATOS DE LA URL
// =========================================

const params =
    new URLSearchParams(
        window.location.search
    );


const id =
    params.get("id");


const tipo =
    params.get("tipo") || "movie";


// =========================================
// ELEMENTOS
// =========================================

const loading =
    document.getElementById(
        "loading"
    );


const detalleContenido =
    document.getElementById(
        "detalleContenido"
    );


const similaresSection =
    document.getElementById(
        "similaresSection"
    );


// =========================================
// CARGAR PELÍCULA
// =========================================

async function cargarPelicula() {

    if (!id) {

        mostrarError(
            "No se encontró la película."
        );

        return;

    }


    try {

        const respuesta =
            await fetch(
                `${TMDB_BASE_URL}/${tipo}/${id}?language=es-ES&append_to_response=credits,recommendations`,
                options
            );


        if (!respuesta.ok) {

            throw new Error(
                "Error al consultar TMDB"
            );

        }


        const pelicula =
            await respuesta.json();


        if (
            !pelicula ||
            pelicula.success === false
        ) {

            mostrarError(
                "No se encontró la información."
            );

            return;

        }


        mostrarInformacion(
            pelicula
        );


        guardarComoVisto(
            pelicula
        );


        loading.style.display =
            "none";


        detalleContenido.classList.remove(
            "oculto"
        );


    } catch (error) {

        console.error(
            "Error al cargar película:",
            error
        );


        mostrarError(
            "No se pudo cargar la información."
        );

    }

}


// =========================================
// MOSTRAR INFORMACIÓN
// =========================================

function mostrarInformacion(
    pelicula
) {

    const titulo =
        pelicula.title ||
        pelicula.name ||
        "Sin título";


    const fecha =
        pelicula.release_date ||
        pelicula.first_air_date ||
        "";


    const año =
        fecha
            ? fecha.split("-")[0]
            : "S/D";


    const poster =
        pelicula.poster_path
            ? TMDB_IMG_URL +
              pelicula.poster_path
            : "https://via.placeholder.com/500x750?text=Sin+poster";


    const descripcion =
        pelicula.overview ||
        "No hay descripción disponible.";


    // =====================================
    // POSTER
    // =====================================

    const posterElement =
        document.getElementById(
            "poster"
        );


    posterElement.src =
        poster;


    posterElement.alt =
        titulo;


    // =====================================
    // TÍTULO
    // =====================================

    document.getElementById(
        "titulo"
    ).textContent =
        titulo;


    // =====================================
    // AÑO
    // =====================================

    document.getElementById(
        "anio"
    ).textContent =
        año;


    // =====================================
    // TIPO
    // =====================================

    document.getElementById(
        "tipoContenido"
    ).textContent =
        tipo === "tv"
            ? "Serie"
            : "Película";


    // =====================================
    // DURACIÓN
    // =====================================

    const duracion =
        document.getElementById(
            "duracion"
        );


    if (tipo === "movie") {

        duracion.textContent =
            pelicula.runtime
                ? `${pelicula.runtime} min`
                : "Duración no disponible";

    } else {

        duracion.textContent =
            pelicula.number_of_seasons
                ? `${pelicula.number_of_seasons} temporada${
                    pelicula.number_of_seasons === 1
                        ? ""
                        : "s"
                }`
                : "Serie";

    }


    // =====================================
    // RATING TMDB
    // =====================================

    document.getElementById(
        "rating"
    ).textContent =
        `⭐ ${
            pelicula.vote_average
                ? pelicula.vote_average.toFixed(1)
                : "N/A"
        }`;


    // =====================================
    // DESCRIPCIÓN
    // =====================================

    document.getElementById(
        "descripcion"
    ).textContent =
        descripcion;


    // =====================================
    // GÉNEROS
    // =====================================

    const generos =
        document.getElementById(
            "generos"
        );


    generos.innerHTML =
        "";


    if (
        pelicula.genres &&
        pelicula.genres.length > 0
    ) {

        pelicula.genres.forEach(
            genero => {

                const elemento =
                    document.createElement(
                        "span"
                    );


                elemento.className =
                    "genero";


                elemento.textContent =
                    genero.name;


                generos.appendChild(
                    elemento
                );

            }
        );

    } else {

        generos.innerHTML =
            "<span>Sin géneros</span>";

    }


    // =====================================
    // ACTORES
    // =====================================

    mostrarActores(
        pelicula
    );


    // =====================================
    // PLATAFORMAS
    // =====================================

    mostrarPlataformas();


    // =====================================
    // VALORACIÓN PERSONAL
    // =====================================

    configurarValoracion();


    cargarValoracionGuardada();


    // =====================================
    // OPINIÓN
    // =====================================

    configurarOpinion();


    cargarOpinionGuardada();


    // =====================================
    // BOTONES
    // =====================================

    configurarBotones(
        pelicula
    );


    // =====================================
    // SIMILARES
    // =====================================

    mostrarRecomendaciones(
        pelicula.recommendations?.results || []
    );

}


// =========================================
// VALORACIÓN PERSONAL
// =========================================

function obtenerClaveContenido() {

    return `${tipo}_${id}`;

}


// =========================================
// CONFIGURAR ESTRELLAS
// =========================================

function configurarValoracion() {

    const estrellas =
        document.querySelectorAll(
            ".estrella"
        );


    if (!estrellas.length) {

        return;

    }


    estrellas.forEach(
        estrella => {

            estrella.addEventListener(
                "mouseenter",
                function() {

                    const valor =
                        Number(
                            this.dataset.valor
                        );


                    pintarEstrellas(
                        valor
                    );

                }
            );


            estrella.addEventListener(
                "mouseleave",
                function() {

                    const valor =
                        obtenerValoracionGuardada();


                    pintarEstrellas(
                        valor
                    );

                }
            );


            estrella.addEventListener(
                "click",
                function() {

                    const valor =
                        Number(
                            this.dataset.valor
                        );


                    guardarValoracion(
                        valor
                    );


                    pintarEstrellas(
                        valor
                    );


                    actualizarTextoValoracion(
                        valor
                    );

                }
            );

        }
    );

}


// =========================================
// PINTAR ESTRELLAS
// =========================================

function pintarEstrellas(
    cantidad
) {

    const estrellas =
        document.querySelectorAll(
            ".estrella"
        );


    estrellas.forEach(
        estrella => {

            const valor =
                Number(
                    estrella.dataset.valor
                );


            if (
                valor <= cantidad
            ) {

                estrella.classList.add(
                    "seleccionada"
                );

            } else {

                estrella.classList.remove(
                    "seleccionada"
                );

            }

        }
    );

}


// =========================================
// GUARDAR VALORACIÓN
// =========================================

function guardarValoracion(
    valor
) {

    let valoraciones =
        JSON.parse(
            localStorage.getItem(
                "cineMatchValoraciones"
            )
        ) || {};


    valoraciones[
        obtenerClaveContenido()
    ] = valor;


    localStorage.setItem(
        "cineMatchValoraciones",
        JSON.stringify(
            valoraciones
        )
    );

}


// =========================================
// OBTENER VALORACIÓN GUARDADA
// =========================================

function obtenerValoracionGuardada() {

    const valoraciones =
        JSON.parse(
            localStorage.getItem(
                "cineMatchValoraciones"
            )
        ) || {};


    return (
        valoraciones[
            obtenerClaveContenido()
        ] || 0
    );

}


// =========================================
// CARGAR VALORACIÓN
// =========================================

function cargarValoracionGuardada() {

    const valor =
        obtenerValoracionGuardada();


    pintarEstrellas(
        valor
    );


    actualizarTextoValoracion(
        valor
    );

}


// =========================================
// TEXTO DE VALORACIÓN
// =========================================

function actualizarTextoValoracion(
    valor
) {

    const texto =
        document.getElementById(
            "textoValoracion"
        );


    if (!texto) {

        return;

    }


    const textos = {

        1: "Muy mala",

        2: "Mala",

        3: "Regular",

        4: "Buena",

        5: "¡Excelente!"

    };


    if (valor === 0) {

        texto.textContent =
            "Todavía no la valoraste";

        return;

    }


    texto.textContent =
        textos[valor];

}


// =========================================
// OPINIÓN
// =========================================

function configurarOpinion() {

    const textarea =
        document.getElementById(
            "opinionTexto"
        );


    const boton =
        document.getElementById(
            "btnGuardarOpinion"
        );


    const contador =
        document.getElementById(
            "contadorOpinion"
        );


    if (
        !textarea ||
        !boton
    ) {

        return;

    }


    textarea.addEventListener(
        "input",
        function() {

            if (contador) {

                contador.textContent =
                    `${textarea.value.length} / 1000`;

            }

        }
    );


    boton.addEventListener(
        "click",
        guardarOpinion
    );

}


// =========================================
// GUARDAR OPINIÓN
// =========================================

function guardarOpinion() {

    const textarea =
        document.getElementById(
            "opinionTexto"
        );


    const mensaje =
        document.getElementById(
            "mensajeOpinion"
        );


    if (!textarea) {

        return;

    }


    const opinion =
        textarea.value.trim();


    let opiniones =
        JSON.parse(
            localStorage.getItem(
                "cineMatchOpiniones"
            )
        ) || {};


    if (opinion === "") {

        delete opiniones[
            obtenerClaveContenido()
        ];

        localStorage.setItem(
            "cineMatchOpiniones",
            JSON.stringify(
                opiniones
            )
        );


        if (mensaje) {

            mensaje.textContent =
                "La opinión fue eliminada.";

            mensaje.className =
                "mensaje-opinion";

        }

        return;

    }


    opiniones[
        obtenerClaveContenido()
    ] = opinion;


    localStorage.setItem(
        "cineMatchOpiniones",
        JSON.stringify(
            opiniones
        )
    );


    if (mensaje) {

        mensaje.textContent =
            "Opinión guardada correctamente.";

        mensaje.className =
            "mensaje-opinion correcto";

    }

}


// =========================================
// CARGAR OPINIÓN
// =========================================

function cargarOpinionGuardada() {

    const textarea =
        document.getElementById(
            "opinionTexto"
        );


    const contador =
        document.getElementById(
            "contadorOpinion"
        );


    if (!textarea) {

        return;

    }


    const opiniones =
        JSON.parse(
            localStorage.getItem(
                "cineMatchOpiniones"
            )
        ) || {};


    const opinion =
        opiniones[
            obtenerClaveContenido()
        ] || "";


    textarea.value =
        opinion;


    if (contador) {

        contador.textContent =
            `${opinion.length} / 1000`;

    }

}


// =========================================
// ACTORES
// =========================================

function mostrarActores(
    pelicula
) {

    const actores =
        document.getElementById(
            "actores"
        );


    if (!actores) {

        return;

    }


    actores.innerHTML =
        "";


    const lista =
        pelicula.credits?.cast?.slice(
            0,
            10
        ) || [];


    if (
        lista.length === 0
    ) {

        actores.innerHTML =
            "<p>No hay información de actores.</p>";

        return;

    }


    lista.forEach(
        actor => {

            const tarjeta =
                document.createElement(
                    "div"
                );


            tarjeta.className =
                "actor";


            const foto =
                actor.profile_path
                    ? TMDB_IMG_URL +
                      actor.profile_path
                    : "https://via.placeholder.com/100x145?text=Actor";


            tarjeta.innerHTML = `

                <img
                    src="${foto}"
                    alt="${actor.name}"
                >

                <p>
                    ${actor.name}
                </p>

            `;


            actores.appendChild(
                tarjeta
            );

        }
    );

}


// =========================================
// PLATAFORMAS
// =========================================

async function mostrarPlataformas() {

    const container =
        document.getElementById(
            "plataformas"
        );


    if (!container) {

        return;

    }


    container.innerHTML = `

        <div class="plataformas-loading">

            <i class="fa-solid fa-spinner fa-spin"></i>

            <span>
                Buscando plataformas...
            </span>

        </div>

    `;


    try {

        const endpoint =
            tipo === "tv"
                ? `${TMDB_BASE_URL}/tv/${id}/watch/providers`
                : `${TMDB_BASE_URL}/movie/${id}/watch/providers`;


        const respuesta =
            await fetch(
                endpoint,
                options
            );


        if (!respuesta.ok) {

            throw new Error(
                "No se pudieron consultar las plataformas."
            );

        }


        const data =
            await respuesta.json();


        const datos =
            data.results?.AR || null;


        console.log(
            "Plataformas Argentina:",
            datos
        );


        if (!datos) {

            container.innerHTML = `

                <div class="sin-plataformas">

                    <i class="fa-solid fa-circle-info"></i>

                    <p>
                        No encontramos información de disponibilidad
                        para Argentina.
                    </p>

                </div>

            `;

            return;

        }


        const enlaceDisponibilidad =
            datos.link || "#";


        container.innerHTML =
            "";


        crearGrupoPlataformas(
            container,
            "Gratis",
            datos.free,
            "gratis",
            "fa-gift",
            enlaceDisponibilidad
        );


        crearGrupoPlataformas(
            container,
            "Gratis con anuncios",
            datos.ads,
            "gratis",
            "fa-circle-play",
            enlaceDisponibilidad
        );


        crearGrupoPlataformas(
            container,
            "Suscripción",
            datos.flatrate,
            "suscripcion",
            "fa-tv",
            enlaceDisponibilidad
        );


        crearGrupoPlataformas(
            container,
            "Alquiler",
            datos.rent,
            "alquiler",
            "fa-ticket",
            enlaceDisponibilidad
        );


        crearGrupoPlataformas(
            container,
            "Compra",
            datos.buy,
            "compra",
            "fa-cart-shopping",
            enlaceDisponibilidad
        );


        if (
            container.children.length === 0
        ) {

            container.innerHTML = `

                <div class="sin-plataformas">

                    <i class="fa-solid fa-circle-info"></i>

                    <p>
                        Esta película no tiene plataformas
                        disponibles actualmente en Argentina.
                    </p>

                </div>

            `;

        }


    } catch (error) {

        console.error(
            "Error mostrando plataformas:",
            error
        );


        container.innerHTML = `

            <div class="sin-plataformas">

                <i class="fa-solid fa-triangle-exclamation"></i>

                <p>
                    No se pudo consultar la disponibilidad
                    de esta película.
                </p>

            </div>

        `;

    }

}


// =========================================
// CREAR GRUPO DE PLATAFORMAS
// =========================================

function crearGrupoPlataformas(
    container,
    titulo,
    plataformas,
    clase,
    icono,
    enlace
) {

    if (
        !plataformas ||
        plataformas.length === 0
    ) {

        return;

    }


    const grupo =
        document.createElement(
            "div"
        );


    grupo.className =
        "grupo-plataformas";


    const encabezado =
        document.createElement(
            "div"
        );


    encabezado.className =
        "plataformas-titulo";


    encabezado.innerHTML = `

        <i class="fa-solid ${icono}"></i>

        <h3>
            ${titulo}
        </h3>

    `;


    grupo.appendChild(
        encabezado
    );


    const lista =
        document.createElement(
            "div"
        );


    lista.className =
        "lista-plataformas";


    plataformas.forEach(
        plataforma => {

            const tarjeta =
                document.createElement(
                    "a"
                );


            tarjeta.className =
                `plataforma-card ${clase}`;


            tarjeta.href =
                enlace || "#";


            tarjeta.target =
                "_blank";


            tarjeta.rel =
                "noopener noreferrer";


            const logo =
                plataforma.logo_path
                    ? `https://image.tmdb.org/t/p/w92${plataforma.logo_path}`
                    : null;


            tarjeta.innerHTML = `

                <div class="plataforma-logo">

                    ${
                        logo
                            ? `
                                <img
                                    src="${logo}"
                                    alt="${plataforma.provider_name}"
                                >
                            `
                            : `
                                <i class="fa-solid fa-tv"></i>
                            `
                    }

                </div>


                <div class="plataforma-info">

                    <span class="plataforma-nombre">
                        ${plataforma.provider_name}
                    </span>

                    <span class="plataforma-ver">

                        Ver disponibilidad

                        <i class="fa-solid fa-arrow-up-right-from-square"></i>

                    </span>

                </div>

            `;


            lista.appendChild(
                tarjeta
            );

        }
    );


    grupo.appendChild(
        lista
    );


    container.appendChild(
        grupo
    );

}


// =========================================
// GUARDAR COMO VISTO
// =========================================

function guardarComoVisto(
    pelicula
) {

    const usuario =
        localStorage.getItem(
            "cineMatchUsuarioActivo"
        );


    if (!usuario) {

        return;

    }


    let vistos =
        JSON.parse(
            localStorage.getItem(
                "cineMatchVistos"
            )
        ) || [];


    const fecha =
        pelicula.release_date ||
        pelicula.first_air_date ||
        "";


    const contenido = {

        id:
            pelicula.id,

        tipo:
            tipo,

        titulo:
            pelicula.title ||
            pelicula.name ||
            "Sin título",

        poster:
            pelicula.poster_path
                ? TMDB_IMG_URL +
                  pelicula.poster_path
                : "",

        año:
            fecha
                ? fecha.split("-")[0]
                : "S/D",

        generos:
            pelicula.genres
                ? pelicula.genres.map(
                    genero =>
                        genero.name
                )
                : [],

        fechaVisto:
            new Date().toISOString()

    };


    vistos =
        vistos.filter(
            item =>
                !(
                    item.id ===
                        contenido.id &&
                    item.tipo ===
                        contenido.tipo
                )
        );


    vistos.unshift(
        contenido
    );


    vistos =
        vistos.slice(
            0,
            20
        );


    localStorage.setItem(
        "cineMatchVistos",
        JSON.stringify(
            vistos
        )
    );

}


// =========================================
// BOTONES
// =========================================

function configurarBotones(
    pelicula
) {

    const botonFavorito =
        document.getElementById(
            "btnFavorito"
        );


    const botonVer =
        document.getElementById(
            "btnVer"
        );


    const botonRecomendar =
        document.getElementById(
            "btnRecomendar"
        );


    if (botonFavorito) {

        botonFavorito.onclick =
            function() {

                guardarFavorito(
                    pelicula
                );

            };

    }


    if (botonVer) {

        botonVer.onclick =
            function() {

                guardarQuieroVer(
                    pelicula
                );

            };

    }


    if (botonRecomendar) {

        botonRecomendar.onclick =
            function() {

                compartirPelicula(
                    pelicula
                );

            };

    }

}


// =========================================
// COMPARTIR
// =========================================

function compartirPelicula(
    pelicula
) {

    const titulo =
        pelicula.title ||
        pelicula.name ||
        "CineMatch";


    const url =
        window.location.href;


    if (
        navigator.clipboard
    ) {

        navigator.clipboard.writeText(
            url
        );


        alert(
            `Enlace de "${titulo}" copiado.`
        );

    } else {

        alert(
            url
        );

    }

}


// =========================================
// FAVORITOS
// =========================================

function guardarFavorito(
    pelicula
) {

    let favoritos =
        JSON.parse(
            localStorage.getItem(
                "cineMatchFavoritos"
            )
        ) || [];


    const contenido =
        crearContenidoGuardado(
            pelicula
        );


    const existe =
        favoritos.some(
            item =>
                item.id ===
                    contenido.id &&
                item.tipo ===
                    contenido.tipo
        );


    if (existe) {

        favoritos =
            favoritos.filter(
                item =>
                    !(
                        item.id ===
                            contenido.id &&
                        item.tipo ===
                            contenido.tipo
                    )
            );


        document.getElementById(
            "btnFavorito"
        ).classList.remove(
            "activo"
        );


        alert(
            "Eliminado de favoritos."
        );


    } else {

        favoritos.push(
            contenido
        );


        document.getElementById(
            "btnFavorito"
        ).classList.add(
            "activo"
        );


        alert(
            "Agregado a favoritos."
        );

    }


    localStorage.setItem(
        "cineMatchFavoritos",
        JSON.stringify(
            favoritos
        )
    );

}


// =========================================
// QUIERO VER
// =========================================

function guardarQuieroVer(
    pelicula
) {

    let lista =
        JSON.parse(
            localStorage.getItem(
                "cineMatchQuieroVer"
            )
        ) || [];


    const contenido =
        crearContenidoGuardado(
            pelicula
        );


    const existe =
        lista.some(
            item =>
                item.id ===
                    contenido.id &&
                item.tipo ===
                    contenido.tipo
        );


    if (existe) {

        lista =
            lista.filter(
                item =>
                    !(
                        item.id ===
                            contenido.id &&
                        item.tipo ===
                            contenido.tipo
                    )
            );


        alert(
            "Eliminado de 'Quiero ver'."
        );


    } else {

        lista.push(
            contenido
        );


        alert(
            "Agregado a 'Quiero ver'."
        );

    }


    localStorage.setItem(
        "cineMatchQuieroVer",
        JSON.stringify(
            lista
        )
    );

}


// =========================================
// DATOS GUARDADOS
// =========================================

function crearContenidoGuardado(
    pelicula
) {

    return {

        id:
            pelicula.id,

        tipo:
            tipo,

        titulo:
            pelicula.title ||
            pelicula.name ||
            "Sin título",

        poster:
            pelicula.poster_path
                ? TMDB_IMG_URL +
                  pelicula.poster_path
                : "",

        año:
            (
                pelicula.release_date ||
                pelicula.first_air_date ||
                ""
            ).split("-")[0],

        generos:
            pelicula.genres
                ? pelicula.genres.map(
                    genero =>
                        genero.name
                )
                : []

    };

}


// =========================================
// RECOMENDACIONES
// =========================================

function mostrarRecomendaciones(
    recomendaciones
) {

    const container =
        document.getElementById(
            "similares"
        );


    if (!container) {

        return;

    }


    container.innerHTML =
        "";


    if (
        !recomendaciones ||
        recomendaciones.length === 0
    ) {

        similaresSection.classList.add(
            "oculto"
        );

        return;

    }


    similaresSection.classList.remove(
        "oculto"
    );


    recomendaciones
        .slice(
            0,
            6
        )
        .forEach(
            pelicula => {

                const titulo =
                    pelicula.title ||
                    pelicula.name ||
                    "Sin título";


                const poster =
                    pelicula.poster_path
                        ? TMDB_IMG_URL +
                          pelicula.poster_path
                        : "https://via.placeholder.com/300x450?text=Sin+poster";


                const tipoRecomendacion =
                    pelicula.media_type === "tv" ||
                    pelicula.first_air_date
                        ? "tv"
                        : "movie";


                const tarjeta =
                    document.createElement(
                        "article"
                    );


                tarjeta.className =
                    "similar-card";


                tarjeta.innerHTML = `

                    <img
                        src="${poster}"
                        alt="${titulo}"
                    >

                    <div class="similar-info">

                        <h3>
                            ${titulo}
                        </h3>

                        <p>
                            ${
                                tipoRecomendacion === "tv"
                                    ? "Serie"
                                    : "Película"
                            }
                        </p>

                    </div>

                `;


                tarjeta.addEventListener(
                    "click",
                    function() {

                        window.location.href =
                            `pelicula.html?id=${pelicula.id}&tipo=${tipoRecomendacion}`;

                    }
                );


                container.appendChild(
                    tarjeta
                );

            }
        );

}


// =========================================
// ERROR
// =========================================

function mostrarError(
    mensaje
) {

    loading.innerHTML = `

        <i class="fa-solid fa-triangle-exclamation"></i>

        <p>
            ${mensaje}
        </p>

    `;

}


// =========================================
// VOLVER
// =========================================

function volverCatalogo() {

    window.location.href =
        "catalogo.html";

}


// =========================================
// INICIAR
// =========================================

cargarPelicula();