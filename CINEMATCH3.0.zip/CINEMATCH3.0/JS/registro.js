/* =====================================================
   REGISTRO - CINEMATCH
   ===================================================== */

const registroForm =
    document.getElementById("registroForm");

const mensaje =
    document.getElementById("mensaje");


/* =====================================================
   REGISTRAR USUARIO
   ===================================================== */

registroForm.addEventListener("submit", function(event) {

    event.preventDefault();


    const usuario =
        document.getElementById("usuario")
        .value
        .trim();


    const email =
        document.getElementById("email")
        .value
        .trim();


    const password =
        document.getElementById("password")
        .value;


    const confirmPassword =
        document.getElementById("confirmPassword")
        .value;


    /* Obtener usuarios existentes */

    let usuarios =
        JSON.parse(
            localStorage.getItem("cineMatchUsuarios")
        ) || [];


    /* =================================================
       COMPROBAR CONTRASEÑAS
       ================================================= */

    if (password !== confirmPassword) {

        mostrarMensaje(
            "Las contraseñas no coinciden.",
            "#e01b25"
        );

        return;
    }


    /* =================================================
       COMPROBAR USUARIO EXISTENTE
       ================================================= */

    const usuarioExiste =
        usuarios.some(function(user) {

            return user.usuario.toLowerCase() ===
                   usuario.toLowerCase();

        });


    if (usuarioExiste) {

        mostrarMensaje(
            "Ese nombre de usuario ya está en uso.",
            "#e01b25"
        );

        return;
    }


    /* =================================================
       COMPROBAR EMAIL EXISTENTE
       ================================================= */

    const emailExiste =
        usuarios.some(function(user) {

            return user.email.toLowerCase() ===
                   email.toLowerCase();

        });


    if (emailExiste) {

        mostrarMensaje(
            "Ese correo ya está registrado.",
            "#e01b25"
        );

        return;
    }


    /* =================================================
       CREAR USUARIO
       ================================================= */

    const nuevoUsuario = {

        usuario: usuario,

        email: email,

        password: password,

        fechaRegistro:
            new Date().toISOString()

    };


    usuarios.push(nuevoUsuario);


    /* Guardar */

    localStorage.setItem(
        "cineMatchUsuarios",
        JSON.stringify(usuarios)
    );


    /* =================================================
       MENSAJE
       ================================================= */

    mostrarMensaje(
        "Cuenta creada correctamente.",
        "#4caf50"
    );


    /* Ir al login */

    setTimeout(function() {

        window.location.href = "login.html";

    }, 1000);

});


/* =====================================================
   MOSTRAR MENSAJE
   ===================================================== */

function mostrarMensaje(texto, color) {

    mensaje.textContent = texto;

    mensaje.style.color = color;

}