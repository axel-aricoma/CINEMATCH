let currentStep = 1;
const totalSteps = 5;

const btnNext = document.getElementById('btnNext');
const btnBack = document.getElementById('btnBack');
const quizForm = document.getElementById('quizForm');
const resultContainer = document.getElementById('resultContainer');
const progressFill = document.getElementById('progressFill');
const stepIndicator = document.getElementById('stepIndicator');

function updateQuizView() {
  document.querySelectorAll('.quiz-step').forEach(step => {
    step.style.display = 'none';
    if (parseInt(step.dataset.step) === currentStep) {
      step.style.display = 'block';
    }
  });

  progressFill.style.width = `${(currentStep / totalSteps) * 100}%`;
  stepIndicator.textContent = `PASO ${currentStep} DE ${totalSteps}`;

  btnBack.disabled = (currentStep === 1);
  btnBack.style.opacity = (currentStep === 1) ? '0.5' : '1';

  if (currentStep === totalSteps) {
    btnNext.innerHTML = 'OBTENER RECOMENDACIÓN <i class="fa-solid fa-wand-magic-sparkles"></i>';
  } else {
    btnNext.innerHTML = 'SIGUIENTE <i class="fa-solid fa-chevron-right"></i>';
  }
}

btnNext.addEventListener('click', async () => {
  if (currentStep < totalSteps) {
    currentStep++;
    updateQuizView();
  } else {
    await obtenerRecomendacion();
  }
});

btnBack.addEventListener('click', () => {
  if (currentStep > 1) {
    currentStep--;
    updateQuizView();
  }
});

async function obtenerRecomendacion() {
  quizForm.style.display = 'none';
  document.querySelector('.quiz-header').style.display = 'none';
  resultContainer.style.display = 'block';

  const plataformas =
Array.from(
document.querySelectorAll('input[name="platform"]:checked')
)
.map(el=>el.value);



const generos =
Array.from(
document.querySelectorAll('input[name="genero"]:checked')
)
.map(el=>el.value);



const tiempo =
document.querySelector('input[name="tiempo"]:checked')?.value;



const ambiente =
document.querySelector('input[name="ambiente"]:checked')?.value;



const tipo =
document.querySelector('input[name="tipo"]:checked')?.value;



const preferencias = {

plataformas,
generos,
tiempo,
ambiente,
tipo

};

  console.log("Preferencias del usuario:", preferencias);

  // Obtener géneros seleccionados
  const checkedGenres = Array.from(document.querySelectorAll('input[name="genero"]:checked')).map(el => el.value);
  const selectedGenreName = checkedGenres[0] || 'Acción';
  const genreId = GENRES_MAP[selectedGenreName] || 28;

  // Consultar TMDB dinámicamente
  const movies = await fetchMoviesByGenre(genreId);

  if (movies && movies.length > 0) {
    // Tomar una película aleatoria de los resultados
    const match = movies[Math.floor(Math.random() * movies.length)];

    document.getElementById('resultTitle').textContent = match.title;
    document.getElementById('resultDesc').textContent = match.overview || 'Sin información detallada disponible.';
    document.getElementById('resultYear').textContent = match.release_date ? match.release_date.split('-')[0] : '';
    document.getElementById('resultImg').src = match.poster_path ? TMDB_IMG_URL + match.poster_path : 'https://via.placeholder.com/500x750';
  } else {
    document.getElementById('resultTitle').textContent = 'No encontramos una película exacta';
    document.getElementById('resultDesc').textContent = 'Prueba cambiando los parámetros del test.';
  }
}

// Limitar selección de géneros a máximo 3

const genreCheckboxes = document.querySelectorAll(
'input[name="genero"]'
);


genreCheckboxes.forEach(check => {

check.addEventListener("change",()=>{


let selected =
document.querySelectorAll(
'input[name="genero"]:checked'
);


if(selected.length > 3){

check.checked = false;

alert(
"Solamente podés elegir hasta 3 géneros"
);

}


});


});

updateQuizView();