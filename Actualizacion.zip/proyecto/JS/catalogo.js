const moviesGrid = document.getElementById('moviesGrid');
const genreList = document.getElementById('genreList');

async function renderMovies(movies) {
  if (!movies || movies.length === 0) {
    moviesGrid.innerHTML = `<p style="color:#aaa;">No se encontraron películas.</p>`;
    return;
  }

  moviesGrid.innerHTML = movies.map(movie => `
    <article class="movie-card">
      <div class="poster-container">
        <img src="${movie.poster_path ? TMDB_IMG_URL + movie.poster_path : 'https://via.placeholder.com/500x750?text=No+Poster'}" alt="${movie.title}">
        <div class="rating-badge"><i class="fa-solid fa-star"></i> ${movie.vote_average ? movie.vote_average.toFixed(1) : 'N/A'}</div>
      </div>
      <div class="movie-info">
        <h3 class="movie-title">${movie.title}</h3>
        <span class="movie-meta">${movie.release_date ? movie.release_date.split('-')[0] : 'S/D'} • Película</span>
        <p class="movie-description">${movie.overview || 'Sin descripción disponible.'}</p>
      </div>
    </article>
  `).join('');
}

// Cargar catálogo inicial
async function initCatalog() {
  const popularMovies = await fetchPopularMovies();
  renderMovies(popularMovies);
}

// Evento de filtro por género
genreList.addEventListener('click', async (e) => {
  const li = e.target.closest('li');
  if (!li) return;

  document.querySelectorAll('#genreList li').forEach(item => item.classList.remove('active'));
  li.classList.add('active');

  const selectedGenre = li.dataset.genre;
  if (selectedGenre === 'all') {
    initCatalog();
  } else {
    const genreId = GENRES_MAP[selectedGenre];
    if (genreId) {
      const movies = await fetchMoviesByGenre(genreId);
      renderMovies(movies);
    }
  }
});

initCatalog();