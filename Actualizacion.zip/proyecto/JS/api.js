// Credenciales
const TMDB_API_KEY = 'eec0d255ca095d4bc0a8a5c782d27333';
const TMDB_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlZWMwZDI1NWNhMDk1ZDRiYzBhOGE1Yzc4MmQyNzMzMyIsIm5iZiI6MTc4NzMzMDA4Ny4xNzEsInN1YiI6IjZhODg3ZTI3YmM4ZWIxMzllZTE5YTY1MCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.e7ncUP3paeiwhsadCRd2baNQVdpISTI1V1C3xq69zzQ';
const OMDB_API_KEY = '7534ca63';

const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMG_URL = 'https://image.tmdb.org/t/p/w500';

// Configuración de encabezados para TMDB
const options = {
  method: 'GET',
  headers: {
    accept: 'application/json',
    Authorization: `Bearer ${TMDB_TOKEN}`
  }
};

// Mapeo de géneros según TMDB IDs
const GENRES_MAP = {
  'Acción': 28,
  'Aventura': 12,
  'Animación': 16,
  'Comedia': 35,
  'Crimen': 80,
  'Documental': 99,
  'Drama': 18,
  'Familiar': 10751,
  'Fantasía': 14,
  'Misterio': 9648,
  'Romance': 10749,
  'Ciencia Ficción': 878,
  'Terror': 27,
  'Thriller': 53
};

// Obtener películas populares de TMDB
async function fetchPopularMovies(page = 1) {
  try {
    const res = await fetch(`${TMDB_BASE_URL}/movie/popular?language=es-ES&page=${page}`, options);
    const data = await res.json();
    return data.results;
  } catch (error) {
    console.error('Error al obtener populares:', error);
    return [];
  }
}

// Buscar películas por género en TMDB
async function fetchMoviesByGenres(genreIds) {

    try {

        const genres = genreIds.join(',');


        const res = await fetch(
            `${TMDB_BASE_URL}/discover/movie?with_genres=${genres}&language=es-ES&sort_by=popularity.desc`,
            options
        );


        const data = await res.json();

        return data.results;


    } catch(error){

        console.error(
        "Error buscando varios géneros:",
        error
        );

        return [];

    }

}