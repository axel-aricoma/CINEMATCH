
// =====================================================
// CINEMATCH - TEST DE GUSTOS
// =====================================================

let currentStep = 1;

const totalSteps = 5;


// =====================================================
// ELEMENTOS DEL HTML
// =====================================================

const btnNext = document.getElementById('btnNext');
const btnBack = document.getElementById('btnBack');

const quizForm = document.getElementById('quizForm');

const resultContainer = document.getElementById('resultContainer');

const progressFill = document.getElementById('progressFill');

const stepIndicator = document.getElementById('stepIndicator');


// =====================================================
// ACTUALIZAR LA VISTA DEL TEST
// =====================================================

function updateQuizView() {

    const steps = document.querySelectorAll('.quiz-step');


    steps.forEach(step => {

        step.style.display = 'none';


        if (parseInt(step.dataset.step) === currentStep) {

            step.style.display = 'block';

        }

    });


    // -----------------------------------------
    // BARRA DE PROGRESO
    // -----------------------------------------

    const progress = (currentStep / totalSteps) * 100;

    progressFill.style.width = `${progress}%`;


    // -----------------------------------------
    // TEXTO DEL PASO
    // -----------------------------------------

    stepIndicator.textContent =
        `PASO ${currentStep} DE ${totalSteps}`;


    // -----------------------------------------
    // BOTÓN ATRÁS
    // -----------------------------------------

    btnBack.disabled = currentStep === 1;


    if (currentStep === 1) {

        btnBack.style.opacity = '0.5';

    } else {

        btnBack.style.opacity = '1';

    }


    // -----------------------------------------
    // BOTÓN SIGUIENTE
    // -----------------------------------------

    if (currentStep === totalSteps) {

        btnNext.innerHTML =
            'OBTENER RECOMENDACIÓN <i class="fa-solid fa-wand-magic-sparkles"></i>';

    } else {

        btnNext.innerHTML =
            'SIGUIENTE <i class="fa-solid fa-chevron-right"></i>';

    }

}


// =====================================================
// BOTÓN SIGUIENTE
// =====================================================

btnNext.addEventListener('click', async function() {


    // Si todavía no estamos en el último paso
    if (currentStep < totalSteps) {


        // Validar el paso antes de avanzar
        if (!validarPaso(currentStep)) {

            return;

        }


        currentStep++;

        updateQuizView();

    }


    // Si estamos en el último paso
    else {

        if (!validarPaso(currentStep)) {

            return;

        }

        await obtenerRecomendacion();

    }

});


// =====================================================
// BOTÓN ATRÁS
// =====================================================

btnBack.addEventListener('click', function() {

    if (currentStep > 1) {

        currentStep--;

        updateQuizView();

    }

});


// =====================================================
// VALIDAR PASOS
// =====================================================

function validarPaso(step) {


    // -----------------------------------------
    // PASO 1 - PLATAFORMAS
    // -----------------------------------------

    if (step === 1) {

        const plataformas =
            document.querySelectorAll(
                'input[name="platform"]:checked'
            );


        if (plataformas.length === 0) {

            alert(
                'Seleccioná al menos una plataforma.'
            );

            return false;

        }

    }


    // -----------------------------------------
    // PASO 2 - GÉNEROS
    // -----------------------------------------

    if (step === 2) {

        const generos =
            document.querySelectorAll(
                'input[name="genero"]:checked'
            );


        if (generos.length === 0) {

            alert(
                'Seleccioná al menos un género.'
            );

            return false;

        }


        if (generos.length > 3) {

            alert(
                'Solamente podés elegir hasta 3 géneros.'
            );

            return false;

        }

    }


    // -----------------------------------------
    // PASO 3 - TIEMPO
    // -----------------------------------------

    if (step === 3) {

        const tiempo =
            document.querySelector(
                'input[name="tiempo"]:checked'
            );


        if (!tiempo) {

            alert(
                'Seleccioná cuánto tiempo tenés disponible.'
            );

            return false;

        }

    }


    // -----------------------------------------
    // PASO 4 - EXPERIENCIA
    // -----------------------------------------

    if (step === 4) {

        const ambiente =
            document.querySelector(
                'input[name="ambiente"]:checked'
            );


        if (!ambiente) {

            alert(
                'Seleccioná qué experiencia querés.'
            );

            return false;

        }

    }


    // -----------------------------------------
    // PASO 5 - TIPO
    // -----------------------------------------

    if (step === 5) {

        const tipo =
            document.querySelector(
                'input[name="tipo"]:checked'
            );


        if (!tipo) {

            alert(
                'Seleccioná película, serie o ambas.'
            );

            return false;

        }

    }


    return true;

}


// =====================================================
// LIMITAR GÉNEROS A 3
// =====================================================

const genreCheckboxes =
    document.querySelectorAll(
        'input[name="genero"]'
    );


genreCheckboxes.forEach(check => {

    check.addEventListener('change', function() {

        const selected =
            document.querySelectorAll(
                'input[name="genero"]:checked'
            );


        if (selected.length > 3) {

            check.checked = false;


            alert(
                'Solamente podés elegir hasta 3 géneros.'
            );

        }

    });

});


// =====================================================
// OBTENER RECOMENDACIÓN
// =====================================================

async function obtenerRecomendacion() {


    // -----------------------------------------
    // OBTENER PLATAFORMAS
    // -----------------------------------------

    const plataformas =
        Array.from(
            document.querySelectorAll(
                'input[name="platform"]:checked'
            )
        ).map(el => el.value);


    // -----------------------------------------
    // OBTENER GÉNEROS
    // -----------------------------------------

    const generos =
        Array.from(
            document.querySelectorAll(
                'input[name="genero"]:checked'
            )
        ).map(el => el.value);


    // -----------------------------------------
    // OBTENER TIEMPO
    // -----------------------------------------

    const tiempo =
        document.querySelector(
            'input[name="tiempo"]:checked'
        )?.value;


    // -----------------------------------------
    // OBTENER EXPERIENCIA
    // -----------------------------------------

    const ambiente =
        document.querySelector(
            'input[name="ambiente"]:checked'
        )?.value;


    // -----------------------------------------
    // OBTENER TIPO
    // -----------------------------------------

    const tipo =
        document.querySelector(
            'input[name="tipo"]:checked'
        )?.value;


    // -----------------------------------------
    // GUARDAR PREFERENCIAS
    // -----------------------------------------

    const preferencias = {

        plataformas,
        generos,
        tiempo,
        ambiente,
        tipo

    };


    console.log(
        'Preferencias del usuario:',
        preferencias
    );


    // =================================================
    // GUARDAR PREFERENCIAS EN EL NAVEGADOR
    // =================================================

    localStorage.setItem(
        'cineMatchPreferencias',
        JSON.stringify(preferencias)
    );


    // =================================================
    // OBTENER IDs DE LOS GÉNEROS
    // =================================================

    const genreIds =
        generos
            .map(genero => GENRES_MAP[genero])
            .filter(id => id !== undefined);


    console.log(
        'IDs de géneros:',
        genreIds
    );


    // =================================================
    // OCULTAR TEST
    // =================================================

    quizForm.style.display = 'none';


    const quizHeader =
        document.querySelector('.quiz-header');


    if (quizHeader) {

        quizHeader.style.display = 'none';

    }


    // =================================================
    // MOSTRAR RESULTADO
    // =================================================

    resultContainer.style.display = 'block';


    document.getElementById('resultTitle').textContent =
        'Buscando recomendación...';


    document.getElementById('resultDesc').textContent =
        'Estamos buscando una película que coincida con tus gustos.';


    // =================================================
    // CONSULTAR TMDB
    // =================================================

    try {

        let movies = [];


        // -----------------------------------------
        // SI EL USUARIO QUIERE PELÍCULAS
        // -----------------------------------------

        if (tipo === 'pelicula' || tipo === 'ambas') {

            movies =
                await fetchMoviesByGenres(genreIds);

        }


        // -----------------------------------------
        // SI EL USUARIO QUIERE SERIES
        // -----------------------------------------

        if (tipo === 'serie') {

            movies =
                await fetchTvByGenres(genreIds);

        }


        // -----------------------------------------
        // SI NO HAY RESULTADOS
        // -----------------------------------------

        if (!movies || movies.length === 0) {

            document.getElementById('resultTitle').textContent =
                'No encontramos una recomendación';


            document.getElementById('resultDesc').textContent =
                'Probá seleccionando otros géneros.';


            return;

        }


        // =================================================
        // ELEGIR UNA RECOMENDACIÓN
        // =================================================

        const match =
            movies[
                Math.floor(
                    Math.random() * movies.length
                )
            ];


        // =================================================
        // MOSTRAR TÍTULO
        // =================================================

        document.getElementById('resultTitle').textContent =
            match.title || match.name;


        // =================================================
        // MOSTRAR DESCRIPCIÓN
        // =================================================

        document.getElementById('resultDesc').textContent =
            match.overview ||
            'Sin información detallada disponible.';


        // =================================================
        // MOSTRAR AÑO
        // =================================================

        const fecha =
            match.release_date ||
            match.first_air_date;


        document.getElementById('resultYear').textContent =
            fecha
                ? fecha.split('-')[0]
                : '';


        // =================================================
        // MOSTRAR POSTER
        // =================================================

        const resultImg =
            document.getElementById('resultImg');


        if (match.poster_path) {

            resultImg.src =
                TMDB_IMG_URL + match.poster_path;

        } else {

            resultImg.src =
                'https://via.placeholder.com/500x750';

        }


        // =================================================
        // GUARDAR PELÍCULA RECOMENDADA
        // =================================================

        localStorage.setItem(
            'cineMatchRecomendacion',
            JSON.stringify(match)
        );


    } catch (error) {

        console.error(
            'Error al obtener recomendación:',
            error
        );


        document.getElementById('resultTitle').textContent =
            'Ocurrió un problema';


        document.getElementById('resultDesc').textContent =
            'No pudimos obtener la recomendación. Revisá la consola del navegador.';

    }

}


// =====================================================
// INICIAR TEST
// =====================================================

updateQuizView();
